import { useLanguage } from '../utils/i18n.jsx'
import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getPredictions } from '../utils/api'
import { BIOMARKER_RANGES } from '../utils/health'
import { Navbar, ToastContainer, PageWrapper, SectionTitle, Spinner, RiskBadge } from '../components/Layout'
import { BiomarkerTrendChart, DiseasePredictionChart } from '../components/Charts'
import { toast } from '../utils/toast'

function BiomarkerGauge({ label, value, unit, min = 0, max = 100, warnMin, warnMax, dangerMin }) {
  const pct = Math.min(100, Math.max(0, ((value - min) / (max - min)) * 100))
  let color = '#10B981'
  if (value >= dangerMin) color = '#EF4444'
  else if (warnMax && value > warnMax) color = '#EF4444'
  else if (value >= warnMin) color = '#F59E0B'

  return (
    <div className="card p-3">
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs text-slate-400 font-medium">{label}</p>
        <span className="text-sm font-bold" style={{ color }}>{value} <span className="text-xs font-normal text-slate-500">{unit}</span></span>
      </div>
      <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'rgba(59,130,246,0.04)' }}>
        <div className="h-2 rounded-full transition-all duration-1000" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  )
}

export default function PatientDetail() {
  const { id } = useParams()
  const [patient, setPatient] = useState(null)
  const [predictions, setPredictions] = useState([])
  const [reasoning, setReasoning] = useState(null)
  const [loading, setLoading] = useState(true)
  const { t } = useLanguage()
  const [activeTab, setActiveTab] = useState("overview")

  useEffect(() => {
    fetchData()
  }, [id])

  const fetchData = async () => {
    setLoading(true)
    try {
      const res = await getPredictions(id)
      const data = res.data
      setPatient(data?.patient || data)
      setPredictions(data?.predictions || [])
      setReasoning(data?.reasoning || null)
    } catch {
      // {t('detail.predictions') + ' — ' + t('common.loading')} - that's normal, user needs to run analysis first
      setPatient(DEMO_PATIENT)
      setPredictions([])
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-grid">
        <Navbar /><ToastContainer />
        <PageWrapper><Spinner label="Loading patient data..." /></PageWrapper>
      </div>
    )
  }

  const bm = patient?.biomarkers || DEMO_PATIENT.biomarkers

  // Build trend data from single value (simulate 6-month trend)
  const buildTrend = (key, currentVal) => {
    if (!currentVal) return []
    const months = ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan']
    return months.map((date, i) => ({
      date,
      value: +(currentVal * (0.92 + i * 0.016 + (Math.random() - 0.5) * 0.03)).toFixed(1),
    }))
  }

  const tabs = [
    { id: 'overview', label: '📋 ' + t('detail.overview') },
    { id: 'biomarkers', label: '🧬 ' + t('detail.biomarkers') },
    { id: 'trends', label: '📈 ' + t('detail.trends') },
    { id: 'predictions', label: '🔮 ' + t('detail.predictions') },
    
  ]

  return (
    <div className="min-h-screen bg-grid">
      <Navbar /><ToastContainer />
      <PageWrapper>
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-slate-500 mb-6">
          <Link to="/dashboard" className="hover:text-blue-400 transition-colors">Dashboard</Link>
          <span>/</span>
          <span className="text-slate-700 font-medium">{patient?.name || 'Patient'}</span>
        </div>

        {/* Patient hero card */}
        <div className="card gradient-border mb-6 animate-fade-in">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl font-bold"
                style={{ background: 'linear-gradient(135deg, #1E40AF, #7C3AED)', color: 'white' }}>
                {(patient?.name || 'P').charAt(0)}
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-800" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
                  {patient?.name || 'Patient'}
                </h1>
                <p className="text-slate-400 text-xs mt-0.5 font-mono">{id}</p>
                <p className="text-slate-500 text-sm">{patient?.age}y · {patient?.sex} · {patient?.city}</p>
                <div className="flex gap-2 mt-2 flex-wrap text-xs text-slate-500">
                  {patient?.smoking && <span className="px-2 py-0.5 rounded-full bg-orange-900/20 text-orange-400 border border-orange-800/30">🚬 Smoker</span>}
                  {patient?.family_history && <span className="px-2 py-0.5 rounded-full bg-purple-900/20 text-purple-400 border border-purple-800/30">🧬 Family History</span>}
                  {patient?.bmi && <span className="px-2 py-0.5 rounded-full bg-blue-900/20 text-blue-400 border border-blue-800/30">📏 BMI {patient.bmi}</span>}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <p className="text-xs text-slate-500 mb-1">{t('detail.overallRisk')}</p>
                <RiskBadge risk={patient?.overall_risk} />
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 overflow-x-auto pb-1">
          {tabs.map(({ id: tid, label }) => (
            <button
              key={tid}
              onClick={() => setActiveTab(tid)}
              className="px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all duration-200"
              style={{
                background: activeTab === tid ? 'rgba(59,130,246,0.2)' : 'transparent',
                border: `1px solid ${activeTab === tid ? '#60a5fa' : 'transparent'}`,
                color: activeTab === tid ? '#93c5fd' : '#64748b',
              }}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 animate-fade-in">
            {Object.entries(BIOMARKER_RANGES).map(([key, range]) =>
              bm[key] != null ? (
                <BiomarkerGauge
                  key={key}
                  label={range.name}
                  value={bm[key]}
                  unit={range.unit}
                  min={range.normal[0] * 0.7}
                  max={Math.max(range.danger?.[1] || 0, range.warning?.[1] || 0) * 1.1}
                  warnMin={range.warning?.[0]}
                  warnMax={range.warning?.[1]}
                  dangerMin={range.danger?.[0]}
                />
              ) : null
            )}
          </div>
        )}

        {/* Biomarkers Tab */}
        {activeTab === 'biomarkers' && (
          <div className="animate-fade-in space-y-4">
            <div className="card overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ borderBottom: '1px solid rgba(59,130,246,0.1)' }}>
                    {['Biomarker', 'Value', 'Unit', 'Normal Range', 'Status'].map(h => (
                      <th key={h} className="text-left py-3 px-4 text-xs uppercase tracking-wide text-slate-500">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(BIOMARKER_RANGES).map(([key, range]) => {
                    if (bm[key] == null) return null
                    const val = bm[key]
                    let status = '✅ Normal'
                    let statusColor = '#10B981'
                    if (key !== 'hdl') {
                      if (val >= range.danger?.[0]) { status = '🚨 High Risk'; statusColor = '#EF4444' }
                      else if (val >= range.warning?.[0]) { status = '⚡ Warning'; statusColor = '#F59E0B' }
                    } else {
                      if (val < 40) { status = '🚨 Low HDL'; statusColor = '#EF4444' }
                      else if (val < 60) { status = '⚡ Sub-optimal'; statusColor = '#F59E0B' }
                    }
                    return (
                      <tr key={key} className="border-b border-blue-900/10 hover:bg-blue-900/5 transition-colors">
                        <td className="py-3 px-4 font-medium text-slate-700">{range.name}</td>
                        <td className="py-3 px-4 font-bold" style={{ color: statusColor }}>{val}</td>
                        <td className="py-3 px-4 text-slate-500">{range.unit}</td>
                        <td className="py-3 px-4 text-slate-500">{range.normal[0]}–{range.normal[1]}</td>
                        <td className="py-3 px-4 text-xs font-semibold" style={{ color: statusColor }}>{status}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Trends Tab */}
        {activeTab === 'trends' && (
          <div className="grid sm:grid-cols-2 gap-4 animate-fade-in">
            {['hba1c', 'fasting_glucose', 'systolic_bp', 'ldl', 'hdl', 'triglycerides'].map(key =>
              bm[key] != null ? (
                <BiomarkerTrendChart
                  key={key}
                  bioKey={key}
                  data={buildTrend(key, bm[key])}
                />
              ) : null
            )}
          </div>
        )}

        {/* Predictions Tab */}
        {activeTab === 'predictions' && (
          <div className="animate-fade-in space-y-4">
            <DiseasePredictionChart predictions={predictions.length ? predictions : []} />
            
            {!predictions.length && (
              <div className="card text-center py-8 text-slate-500">
                <p className="text-lg mb-2">{t('detail.predictions') + ' — ' + t('common.loading')}</p>
                <p className="text-sm">Submit a new patient entry and run AI Analysis to generate predictions.</p>
              </div>
            )}

            {/* Intervention Plan */}
            {reasoning?.agent4 && (
              <div className="card" style={{ border: '2px solid #86efac', background: '#f0fdf4' }}>
                <p className="font-bold text-base mb-3" style={{ color: '#16a34a' }}>💊 {t('common.interventionPlan')}</p>
                <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">{reasoning.agent4}</p>
              </div>
            )}

            {/* Agent Reasoning */}
            {reasoning && (reasoning.agent1 || reasoning.agent2 || reasoning.agent3) && (
              <div className="card">
                <p className="font-bold text-base mb-3 text-slate-800">🔍 {t('common.agentReasoning')}</p>
                <div className="space-y-3">
                  {[
                    { key: 'agent1', label: t('common.temporalAnalysis'), icon: '📈' },
                    { key: 'agent2', label: t('common.biomarkerCorrelations'), icon: '🔗' },
                    { key: 'agent3', label: t('common.diseaseTrajectory'), icon: '🔮' },
                  ].map(({ key, label, icon }) => {
                    const text = reasoning[key]
                    if (!text) return null
                    return (
                      <div key={key} className="p-3 rounded-lg" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                        <p className="font-semibold text-xs text-slate-600 mb-1">{icon} {label}</p>
                        <p className="text-sm text-slate-700 leading-relaxed">{text}</p>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
        )}

      </PageWrapper>
    </div>
  )
}

const DEMO_PATIENT = {
  name: 'Arjun Sharma', age: 45, sex: 'Male', city: 'Mumbai',
  overall_risk: 'High', bmi: 27.4, smoking: true, family_history: true,
  biomarkers: {
    hba1c: 6.8, fasting_glucose: 118, systolic_bp: 142, diastolic_bp: 88,
    ldl: 145, hdl: 38, triglycerides: 195, creatinine: 1.1,
    tsh: 3.2, vitamin_d: 18, uric_acid: 6.8, hemoglobin: 13.5,
  },
}

const DEMO_PREDICTIONS = [
  {
    disease: 'Type 2 Diabetes',
    probability: 72,
    timeline: { '1yr': 45, '3yr': 60, '5yr': 72, '10yr': 85 },
    drivers: ['HbA1c', 'Fasting Glucose', 'BMI'],
  },
  {
    disease: 'Hypertension',
    probability: 68,
    timeline: { '1yr': 40, '3yr': 55, '5yr': 68, '10yr': 80 },
    drivers: ['Systolic BP', 'Diastolic BP', 'Sodium intake'],
  },
  {
    disease: 'Coronary Artery Disease',
    probability: 55,
    timeline: { '1yr': 20, '3yr': 38, '5yr': 55, '10yr': 72 },
    drivers: ['LDL', 'HDL', 'Triglycerides'],
  },
  {
    disease: 'Chronic Kidney Disease',
    probability: 30,
    timeline: { '1yr': 10, '3yr': 20, '5yr': 30, '10yr': 45 },
    drivers: ['Creatinine', 'Uric Acid', 'Blood Pressure'],
  },
]
