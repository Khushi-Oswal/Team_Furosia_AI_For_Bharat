import { useState, useEffect, useRef } from 'react'
import { useParams, Link } from 'react-router-dom'
import { analyzePatient, getReasoning, getPredictions } from '../utils/api'
import { Navbar, ToastContainer, PageWrapper, Spinner, RiskBadge } from '../components/Layout'
import { AgentFlowDiagram, AgentReasoningPanel, AgentProgressSteps, AGENTS } from '../components/AgentPanel'
import { DiseasePredictionChart } from '../components/Charts'
import { TranslationPanel } from '../components/HealthTools'
import { toast } from '../utils/toast'

const ANALYSIS_STEPS = [
  'Connecting to Amazon Bedrock Nova...',
  'Agent 1: Scanning temporal biomarker patterns...',
  'Supervisor: Evaluating analysis path...',
  'Agent 2: Detecting biomarker correlations...',
  'Agent 3: Computing disease probabilities...',
  'Agent 4: Generating intervention plan...',
  'Finalizing results...',
]

export default function AnalyzeResults() {
  const { id } = useParams()
  const [status, setStatus] = useState('idle') // idle | running | done | error
  const [stepIdx, setStepIdx] = useState(0)
  const [agentStatuses, setAgentStatuses] = useState({})
  const [reasoning, setReasoning] = useState(null)
  const [predictions, setPredictions] = useState([])
  const [sessionId, setSessionId] = useState(null)
  const intervalRef = useRef(null)

  const updateAgentStatus = (agent, stat) =>
    setAgentStatuses((prev) => ({ ...prev, [agent]: stat }))

  const runAnalysis = async () => {
    setStatus('running')
    setStepIdx(0)
    setReasoning(null)
    setAgentStatuses({})

    try {
      // Animate step progression
      let s = 0
      intervalRef.current = setInterval(() => {
        s++
        setStepIdx(s)
        if (s === 1) updateAgentStatus('agent1', 'running')
        if (s === 2) { updateAgentStatus('agent1', 'complete'); updateAgentStatus('supervisor', 'running') }
        if (s === 3) { updateAgentStatus('supervisor', 'complete'); updateAgentStatus('agent2', 'running') }
        if (s === 4) { updateAgentStatus('agent2', 'complete'); updateAgentStatus('agent3', 'running') }
        if (s === 5) { updateAgentStatus('agent3', 'complete'); updateAgentStatus('agent4', 'running') }
        if (s >= 6) { clearInterval(intervalRef.current) }
      }, 1400)

      // Run ETL first (silent - ensures Gold data exists)
      try {
        const { runETL } = await import('../utils/api')
        await runETL(id)
      } catch(e) { console.warn('ETL pre-run:', e) }

      // Call AI Analysis
      const res = await analyzePatient(id)
      const data = res.data
      const sid = data?.session_id || data?.sessionId
      setSessionId(sid)

      clearInterval(intervalRef.current)
      setStepIdx(7)
      updateAgentStatus('agent4', 'complete')

      // Fetch reasoning
      if (sid) {
        try {
          const rRes = await getReasoning(sid)
          setReasoning(rRes.data)
        } catch { setReasoning(DEMO_REASONING) }
      } else {
        setReasoning(data?.reasoning || DEMO_REASONING)
      }

      // Fetch predictions
      try {
        const pRes = await getPredictions(id)
        setPredictions(pRes.data?.predictions || DEMO_PREDICTIONS)
      } catch { setPredictions(DEMO_PREDICTIONS) }

      setStatus('done')
      toast.success('AI Analysis complete!')
    } catch (err) {
      clearInterval(intervalRef.current)
      toast.error('Analysis failed: ' + (err.message || 'Unknown error') + '. Please retry.')
      setStatus('error')
      Object.keys({ agent1: 1, supervisor: 1, agent2: 1, agent3: 1, agent4: 1 }).forEach(
        (k) => updateAgentStatus(k, 'complete')
      )
    }
  }

  useEffect(() => () => clearInterval(intervalRef.current), [])

  const agentColors = ['#3B82F6', '#8B5CF6', '#EC4899', '#10B981']
  const agentIcons = ['📈', '🔗', '🔮', '💊']
  const agentNames = ['Temporal Pattern Analysis', 'Biomarker Correlations', 'Disease Predictions', 'Intervention Plan']

  const reportText = reasoning
    ? `AI Analysis for Patient ${id}. ${reasoning.agent1 || ''} ${reasoning.agent3 || ''}`
    : ''

  return (
    <div className="min-h-screen bg-grid">
      <Navbar /><ToastContainer />
      <PageWrapper>
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-slate-500 mb-6">
          <Link to="/dashboard" className="hover:text-blue-400">Dashboard</Link>
          <span>/</span>
          <Link to={`/patient/${id}`} className="hover:text-blue-400">Patient {id}</Link>
          <span>/</span>
          <span className="text-slate-600">AI Analysis</span>
        </div>

        {/* Header */}
        <div className="flex flex-wrap items-start justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-black gradient-text mb-1" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
              AI Analysis
            </h1>
            <p className="text-slate-400 text-sm">4-Agent Amazon Bedrock Nova · Patient <span className="text-slate-700 font-mono">{id}</span></p>
          </div>

          {status === 'idle' && (
            <button className="btn-primary text-base px-6 py-3 animate-pulse-ring" onClick={runAnalysis}>
              🤖 Run AI Analysis
            </button>
          )}
          {status === 'running' && (
            <button className="btn-secondary text-base px-6 py-3" disabled>
              ⏳ Analyzing...
            </button>
          )}
          {status === 'done' && (
            <button className="btn-secondary text-base px-6 py-3" onClick={runAnalysis}>
              🔄 Re-analyze
            </button>
          )}
        </div>

        {/* Idle state */}
        {status === 'idle' && (
          <div className="card text-center py-20 animate-fade-in">
            <div className="text-6xl mb-4 animate-float">🧬</div>
            <h2 className="text-2xl font-bold text-slate-700 mb-3">Ready to Analyze</h2>
            <p className="text-slate-400 max-w-md mx-auto mb-6 text-sm leading-relaxed">
              Click "Run AI Analysis" to trigger all 4 Amazon Bedrock Nova agents. They will analyze biomarker patterns, detect correlations, predict diseases, and generate an intervention plan.
            </p>
            <button className="btn-primary text-base px-8 py-3" onClick={runAnalysis}>
              🤖 Start Analysis
            </button>
          </div>
        )}

        {/* Running state */}
        {status === 'running' && (
          <div className="space-y-6 animate-fade-in">
            <AgentFlowDiagram agentStatuses={agentStatuses} />
            <AgentProgressSteps currentStep={stepIdx} steps={ANALYSIS_STEPS} />
          </div>
        )}

        {/* Done state */}
        {status === 'done' && reasoning && (
          <div className="space-y-6 animate-fade-in">
            {/* Success banner */}
            <div className="flex items-center gap-3 p-4 rounded-xl"
              style={{ background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.25)' }}>
              <span className="text-2xl">✅</span>
              <div>
                <p className="font-semibold text-emerald-400">Analysis Complete</p>
                <p className="text-xs text-slate-500">All 4 agents have processed patient {id}'s biomarkers</p>
              </div>
              {sessionId && <p className="ml-auto text-xs text-slate-600 font-mono">Session: {sessionId}</p>}
            </div>

            {/* Agent flow */}
            <AgentFlowDiagram agentStatuses={{ agent1: 'complete', supervisor: 'complete', agent2: 'complete', agent3: 'complete', agent4: 'complete' }} />

            {/* Supervisor Decision */}
            {reasoning.supervisor && (
              <div className="rounded-xl p-4"
                style={{ background: 'rgba(245,158,11,0.06)', border: '1px solid rgba(245,158,11,0.25)' }}>
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-xl">🧠</span>
                  <p className="font-semibold text-amber-400 text-sm">Supervisor Decision</p>
                  <span className="px-2 py-0.5 rounded text-xs font-bold ml-auto"
                    style={{ background: 'rgba(16,185,129,0.15)', color: '#10B981', border: '1px solid rgba(16,185,129,0.3)' }}>
                    {reasoning.supervisor_decision || 'CONTINUE'}
                  </span>
                </div>
                <p className="text-sm text-slate-600 leading-relaxed">{reasoning.supervisor}</p>
              </div>
            )}

            {/* Agent reasoning panels */}
            <div className="space-y-4">
              {AGENTS.map((agent) => (
                <AgentReasoningPanel
                  key={agent.id}
                  agentId={agent.id}
                  agentName={agentNames[agent.id - 1]}
                  icon={agentIcons[agent.id - 1]}
                  color={agentColors[agent.id - 1]}
                  content={reasoning[`agent${agent.id}`]}
                />
              ))}
            </div>

            {/* Disease predictions */}
            {predictions.length > 0 && (
              <DiseasePredictionChart predictions={predictions} />
            )}

            {/* Translation */}
            {reportText && <TranslationPanel text={reportText} />}
          </div>
        )}
      </PageWrapper>
    </div>
  )
}

const DEMO_REASONING = {
  agent1: `Temporal analysis reveals concerning upward trends across multiple metabolic markers over the past 6 months:
• HbA1c: 5.9% → 6.8% (+0.9%, rate of 0.15%/month) — approaching diabetic threshold
• Fasting Glucose: 102 → 118 mg/dL (+15.7%) — consistent pre-diabetic elevation  
• Systolic BP: 130 → 142 mmHg (+9.2%) — crossed hypertensive threshold 3 months ago
• HDL declining: 45 → 38 mg/dL — unfavorable cardiovascular trajectory
• Vitamin D critically low at 18 ng/mL — associated with insulin resistance

⚠️ Rate of deterioration is accelerating — immediate intervention recommended.`,

  supervisor: `Based on Agent 1's temporal analysis, significant multi-system dysfunction is detected. The concurrent metabolic, cardiovascular, and micronutrient deficiencies indicate compound systemic risk. Decision: CONTINUE full analysis chain. All 3 remaining agents required for comprehensive risk stratification.`,

  supervisor_decision: 'CONTINUE',

  agent2: `Biomarker cluster analysis identified 3 high-risk correlation clusters:

🔴 Cluster A — Metabolic Syndrome (Correlation r=0.89):
  HbA1c + Fasting Glucose + Triglycerides + BMI (27.4)
  → Classic insulin resistance pattern with adiposity

🟡 Cluster B — Cardiovascular Risk (Correlation r=0.74):
  LDL (145) + HDL (38) + Systolic BP (142) + Triglycerides (195)
  → Atherogenic dyslipidemia profile — 2.3x population baseline risk

🟡 Cluster C — Renal Stress Indicators (Correlation r=0.61):
  Uric Acid (6.8) + Creatinine (1.1) + Hypertension
  → Early nephropathy monitoring warranted`,

  agent3: `Disease probability forecast for Patient P001 (Male, 45yr, Mumbai):

1. Type 2 Diabetes: 72% by Year 5 (85% by Year 10)
   HbA1c trajectory and fasting glucose are primary drivers.
   Without intervention, likely diagnosis within 8–14 months.

2. Essential Hypertension: 68% by Year 5
   BP already exceeds 140 mmHg. Risk compounds with Cluster A.

3. Coronary Artery Disease: 55% by Year 5
   LDL:HDL ratio of 3.8 (optimal <2.5). Inflammatory profile elevated.

4. Chronic Kidney Disease: 30% by Year 5
   Early markers present. Risk escalates if hypertension uncontrolled.`,

  agent4: `Personalized Intervention Plan — Priority: HIGH

🥗 Dietary Interventions:
  • Adopt low-glycemic index diet (target GI <55 for all foods)
  • Reduce refined carbohydrates — cap at 100g/day
  • Increase omega-3 intake: fatty fish 3x/week or supplement 2g EPA+DHA/day
  • Reduce sodium to <1500mg/day to address hypertension
  • Vitamin D3 supplementation: 4000 IU/day for 3 months, then 2000 IU maintenance

🏃 Exercise Protocol:
  • Target: 150 min/week moderate aerobic exercise
  • Resistance training: 3x/week (improves insulin sensitivity by 20–35%)
  • Start: 30-min brisk walks daily — immediate BP benefit

📊 Monitoring Schedule (Next 6 Months):
  • HbA1c + Fasting Glucose: Monthly
  • Lipid Panel: 3-monthly
  • BP: Weekly home monitoring
  • Vitamin D, Creatinine: 3-monthly

💊 Clinical Referrals:
  • Endocrinologist (pre-diabetes management)
  • Cardiologist (lipid optimization)
  • Dietitian (personalized meal planning)`,
}

const DEMO_PREDICTIONS = [
  { disease: 'Type 2 Diabetes', probability: 72, timeline: { '1yr': 45, '3yr': 60, '5yr': 72, '10yr': 85 }, drivers: ['HbA1c', 'Fasting Glucose', 'BMI'] },
  { disease: 'Hypertension', probability: 68, timeline: { '1yr': 40, '3yr': 55, '5yr': 68, '10yr': 80 }, drivers: ['Systolic BP', 'Sodium', 'Stress'] },
  { disease: 'Coronary Artery Disease', probability: 55, timeline: { '1yr': 20, '3yr': 38, '5yr': 55, '10yr': 72 }, drivers: ['LDL', 'HDL', 'Triglycerides'] },
  { disease: 'Chronic Kidney Disease', probability: 30, timeline: { '1yr': 10, '3yr': 20, '5yr': 30, '10yr': 45 }, drivers: ['Creatinine', 'Uric Acid', 'BP'] },
]
