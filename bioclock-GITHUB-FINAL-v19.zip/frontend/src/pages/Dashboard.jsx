import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../utils/auth.jsx'
import { useLanguage } from '../utils/i18n.jsx'
import { getPatients } from '../utils/api'
import { Navbar, ToastContainer, PageWrapper, SectionTitle, Spinner, RiskBadge } from '../components/Layout'
import { PatientCard, StatCard } from '../components/PatientCard'
import { toast } from '../utils/toast'

export default function Dashboard() {
    const { user } = useAuth()
    const { t } = useLanguage()
    const [patients, setPatients] = useState([])
    const [loading, setLoading] = useState(true)
    const [search, setSearch] = useState('')
    const [filterRisk, setFilterRisk] = useState('all')

    useEffect(() => {
        fetchPatients()
    }, [])

    const fetchPatients = async () => {
        setLoading(true)
        try {
            const res = await getPatients(user?.sub || user?.email)
            const list = res.data?.patients || res.data || []
            setPatients(Array.isArray(list) ? list : [])
        } catch (err) {
            toast.info('Loading patients...')
            // Demo data for hackathon
            setPatients(DEMO_PATIENTS)
        } finally {
            setLoading(false)
        }
    }

    const filtered = patients.filter((p) => {
        const matchSearch = !search ||
            (p.name || '').toLowerCase().includes(search.toLowerCase()) ||
            String(p.patient_id).includes(search)
        const matchRisk = filterRisk === 'all' ||
            (p.overall_risk || '').toLowerCase() === filterRisk.toLowerCase()
        return matchSearch && matchRisk
    })

    // Stats
    const riskCounts = patients.reduce((acc, p) => {
        const r = (p.overall_risk || 'unknown').toLowerCase()
        acc[r] = (acc[r] || 0) + 1
        return acc
    }, {})

    return (
        <div className="min-h-screen bg-grid">
            <Navbar />
            <ToastContainer />
            <PageWrapper>
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <SectionTitle icon="📊" title={t('dashboard.title')} subtitle={t('dashboard.subtitle')} />
                    <div className="flex gap-3">
                        <button onClick={fetchPatients} className="btn-secondary">
                            🔄 {t("dashboard.refresh")}
                        </button>
                        <Link to="/input" className="btn-primary">+ {t("nav.newPatient")}</Link>
                    </div>
                </div>

                {/* Stat cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
                    <StatCard icon="👥" label={t('dashboard.totalPatients')} value={patients.length} color="#60a5fa" sub="All registered" />
                    <StatCard icon="🟢" label={t('dashboard.lowRisk')} value={riskCounts.low || 0} color="#10B981" sub="< 30% risk score" />
                    <StatCard icon="🟡" label={t('dashboard.moderateRisk')} value={riskCounts.moderate || 0} color="#F59E0B" sub="30–60% risk score" />
                    <StatCard icon="🔴" label={t('dashboard.highRisk')} value={(riskCounts.high || 0) + (riskCounts.critical || 0)} color="#EF4444" sub="> 60% risk score" />
                </div>

                {/* Filters */}
                <div className="flex flex-wrap gap-3 mb-6">
                    <input
                        className="input-field max-w-xs"
                        placeholder={t('dashboard.search')}
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                    <div className="flex gap-2 flex-wrap">
                        {['all', 'low', 'moderate', 'high', 'critical'].map((r) => (
                            <button
                                key={r}
                                onClick={() => setFilterRisk(r)}
                                className="px-3 py-2 rounded-lg text-xs font-semibold uppercase tracking-wide transition-all duration-200"
                                style={{
                                    background: filterRisk === r ? 'rgba(59,130,246,0.2)' : 'rgba(30,64,175,0.08)',
                                    border: `1px solid ${filterRisk === r ? '#60a5fa' : 'rgba(30,64,175,0.2)'}`,
                                    color: filterRisk === r ? '#93c5fd' : '#64748b',
                                }}
                            >
                                {r}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Risk distribution bar */}
                {patients.length > 0 && (
                    <div className="card mb-6">
                        <p className="text-xs text-slate-500 uppercase tracking-wide mb-3">Risk Distribution</p>
                        <div className="flex h-3 rounded-full overflow-hidden gap-0.5">
                            {[
                                { key: 'low', color: '#10B981' },
                                { key: 'moderate', color: '#F59E0B' },
                                { key: 'high', color: '#EF4444' },
                                { key: 'critical', color: '#FF1744' },
                            ].map(({ key, color }) => {
                                const pct = ((riskCounts[key] || 0) / patients.length) * 100
                                return pct > 0 ? (
                                    <div key={key} className="h-full rounded-sm transition-all duration-700"
                                        title={`${key}: ${riskCounts[key]}`}
                                        style={{ width: `${pct}%`, background: color }} />
                                ) : null
                            })}
                        </div>
                        <div className="flex gap-4 mt-2">
                            {[
                                { key: 'low', color: '#10B981', label: 'Low' },
                                { key: 'moderate', color: '#F59E0B', label: 'Moderate' },
                                { key: 'high', color: '#EF4444', label: 'High' },
                                { key: 'critical', color: '#FF1744', label: 'Critical' },
                            ].map(({ key, color, label }) =>
                                riskCounts[key] ? (
                                    <div key={key} className="flex items-center gap-1.5 text-xs text-slate-500">
                                        <span className="w-2 h-2 rounded-full inline-block" style={{ background: color }} />
                                        {label} ({riskCounts[key]})
                                    </div>
                                ) : null
                            )}
                        </div>
                    </div>
                )}

                {/* Patient grid */}
                {loading ? (
                    <Spinner label="Loading patients..." />
                ) : filtered.length === 0 ? (
                    <div className="card text-center py-16">
                        <p className="text-4xl mb-4">🔍</p>
                        <p className="text-slate-400 font-medium">No patients found</p>
                        <p className="text-slate-600 text-sm mt-1">Try adjusting your search or filter</p>
                        <Link to="/input" className="btn-primary mt-4 inline-flex">+ Add First Patient</Link>
                    </div>
                ) : (
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                        {filtered.map((p, i) => (
                            <PatientCard key={p.patient_id || i} patient={p} index={i} />
                        ))}
                    </div>
                )}
            </PageWrapper>
        </div>
    )
}

const DEMO_PATIENTS = [
    { patient_id: 'P001', name: 'Arjun Sharma', age: 45, sex: 'Male', city: 'Mumbai', overall_risk: 'High', biomarkers_count: 18, created_at: '2025-01-15' },
    { patient_id: 'P002', name: 'Priya Patel', age: 38, sex: 'Female', city: 'Ahmedabad', overall_risk: 'Moderate', biomarkers_count: 14, created_at: '2025-01-20' },
    { patient_id: 'P003', name: 'Rahul Gupta', age: 52, sex: 'Male', city: 'Delhi', overall_risk: 'Critical', biomarkers_count: 20, created_at: '2025-02-01' },
    { patient_id: 'P004', name: 'Sneha Reddy', age: 29, sex: 'Female', city: 'Hyderabad', overall_risk: 'Low', biomarkers_count: 12, created_at: '2025-02-10' },
    { patient_id: 'P005', name: 'Vikram Singh', age: 61, sex: 'Male', city: 'Chennai', overall_risk: 'High', biomarkers_count: 22, created_at: '2025-02-15' },
    { patient_id: 'P006', name: 'Ananya Iyer', age: 34, sex: 'Female', city: 'Bangalore', overall_risk: 'Low', biomarkers_count: 16, created_at: '2025-02-18' },
]
