import { useLanguage } from '../utils/i18n.jsx'
import { Link } from 'react-router-dom'
import { Navbar, ToastContainer } from '../components/Layout'

const features = [
    { icon: '🧬', title: 'Multi-Tier Biomarker Analysis', desc: 'Comprehensive analysis across metabolic, cardiac, renal, thyroid, hormonal and micronutrient markers.' },
    { icon: '🤖', title: '4 AI Agents', desc: 'Amazon Bedrock Nova powers temporal analysis, correlation detection, predictions, and interventions.' },
    { icon: '📊', title: 'Disease Timeline', desc: 'Predict chronic disease risk at 1, 3, 5, and 10-year horizons with probability scores.' },
    { icon: '🌐', title: 'Multilingual Reports', desc: 'Translate health reports to Hindi, Tamil, Telugu, Marathi, Bengali, and more.' },
    { icon: '⚙️', title: 'Medallion Pipeline', desc: 'Bronze → Silver → Gold data architecture for enterprise-grade data quality.' },
    { icon: '🏥', title: 'India-Focused', desc: 'Calibrated for the Indian population with region-specific risk factors and interventions.' },
]

const stats = [
    { num: '6', label: 'Health Tiers' },
    { num: '4', label: 'AI Agents' },
    { num: '8', label: 'Languages' },
    { num: '10yr', label: 'Predictions' },
]

export default function Landing() {
    const { t } = useLanguage()
    return (
        <div className="min-h-screen bg-grid">
            <Navbar />
            <ToastContainer />

            {/* Hero */}
            <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
                {/* Animated background orbs */}
                <div className="absolute inset-0 overflow-hidden pointer-events-none">
                    <div className="absolute top-1/4 -left-32 w-96 h-96 rounded-full blur-3xl opacity-20 animate-float"
                        style={{ background: 'radial-gradient(circle, rgba(59,130,246,0.15), transparent)' }} />
                    <div className="absolute bottom-1/4 -right-32 w-96 h-96 rounded-full blur-3xl opacity-15 animate-float"
                        style={{ background: 'radial-gradient(circle, rgba(139,92,246,0.1), transparent)', animationDelay: '1.5s' }} />
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full blur-3xl opacity-5"
                        style={{ background: 'radial-gradient(circle, rgba(59,130,246,0.08), transparent)' }} />
                </div>

                <div className="relative max-w-5xl mx-auto px-6 text-center animate-fade-in">
                    {/* Badge */}
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-8"
                        style={{ background: 'rgba(59,130,246,0.04)', border: '1px solid rgba(59,130,246,0.3)', color: '#1E40AF' }}>
                        <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse inline-block" />
                        Powered by Amazon Bedrock Nova AI
                    </div>

                    {/* Headline */}
                    <h1 className="text-5xl sm:text-7xl font-black mb-6 leading-tight" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
                        <span className="gradient-text">{ t('landing.predict') }</span>{' '}
                        <span className="text-slate-800">{ t('landing.prevent') }</span>{' '}
                        <span className="gradient-text-green">{ t('landing.thrive') }</span>
                    </h1>
                    <p className="text-xl sm:text-2xl text-slate-400 mb-4 font-light">
                        {t('landing.subtitle')}
                    </p>
                    <p className="text-base text-slate-500 max-w-2xl mx-auto mb-10 leading-relaxed">
                        {t('landing.description')}
                    </p>

                    {/* CTA Buttons */}
                    <div className="flex flex-wrap items-center justify-center gap-4 mb-16">
                        <Link to="/input" className="btn-primary text-base px-8 py-3">
                            🚀 {t('landing.getStarted')}
                        </Link>
                        <Link to="/dashboard" className="btn-secondary text-base px-8 py-3">
                            📊 {t('landing.viewDashboard')}
                        </Link>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl mx-auto">
                        {stats.map(({ num, label }) => (
                            <div key={label} className="glass rounded-2xl p-4 text-center">
                                <p className="text-3xl font-black gradient-text">{num}</p>
                                <p className="text-xs text-slate-500 mt-1 uppercase tracking-wide">{label}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Features */}
            <section className="py-20 px-6">
                <div className="max-w-6xl mx-auto">
                    <div className="text-center mb-12">
                        <h2 className="text-3xl sm:text-4xl font-bold mb-3" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
                            <span className="gradient-text">Next-Gen</span> Health Intelligence
                        </h2>
                        <p className="text-slate-400 max-w-xl mx-auto">
                            A complete predictive health platform built for India's diverse population.
                        </p>
                    </div>
                    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
                        {features.map(({ icon, title, desc }, i) => (
                            <div
                                key={title}
                                className="card glass-hover animate-fade-in"
                                style={{ animationDelay: `${i * 80}ms` }}
                            >
                                <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl mb-4"
                                    style={{ background: 'linear-gradient(135deg, rgba(30,64,175,0.3), rgba(124,58,237,0.2))', border: '1px solid rgba(59,130,246,0.2)' }}>
                                    {icon}
                                </div>
                                <h3 className="font-semibold text-slate-800 text-base mb-2">{title}</h3>
                                <p className="text-sm text-slate-500 leading-relaxed">{desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Agent Flow Visual */}
            <section className="py-16 px-6">
                <div className="max-w-4xl mx-auto">
                    <div className="text-center mb-10">
                        <h2 className="text-2xl sm:text-3xl font-bold mb-2" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
                            Multi-Agent AI Chain
                        </h2>
                        <p className="text-slate-400 text-sm">How our 4 specialized AI agents collaborate to generate your health predictions</p>
                    </div>
                    <div className="card gradient-border">
                        <div className="flex flex-wrap items-center justify-center gap-3">
                            {[
                                { n: '1', label: 'Temporal\nAnalysis', icon: '📈', color: '#3B82F6' },
                                { arrow: true },
                                { n: '🧠', label: 'Supervisor\nDecision', icon: '', color: '#F59E0B', sup: true },
                                { arrow: true },
                                { n: '2', label: 'Biomarker\nCorrelations', icon: '🔗', color: '#8B5CF6' },
                                { arrow: true },
                                { n: '3', label: 'Disease\nPredictions', icon: '🔮', color: '#EC4899' },
                                { arrow: true },
                                { n: '4', label: 'Intervention\nPlan', icon: '💊', color: '#10B981' },
                            ].map((item, i) =>
                                item.arrow ? (
                                    <div key={i} className="text-slate-700 text-lg font-bold">→</div>
                                ) : (
                                    <div key={i} className="flex flex-col items-center gap-2 px-2">
                                        <div
                                            className="w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-bold"
                                            style={{
                                                background: `linear-gradient(135deg, ${item.color}30, ${item.color}15)`,
                                                border: `1px solid ${item.color}40`,
                                                color: item.color,
                                            }}
                                        >
                                            {item.sup ? '🧠' : item.icon}
                                        </div>
                                        <p className="text-xs text-center text-slate-400 font-medium leading-tight whitespace-pre">
                                            {item.label}
                                        </p>
                                    </div>
                                )
                            )}
                        </div>
                    </div>
                </div>
            </section>

            {/* CTA footer */}
            <section className="py-20 px-6 text-center">
                <div className="max-w-2xl mx-auto glass rounded-3xl p-10" style={{ border: '1px solid rgba(59,130,246,0.2)' }}>
                    <h2 className="text-3xl font-bold mb-4 gradient-text">Ready to know your BioClock?</h2>
                    <p className="text-slate-400 mb-6">Enter your biomarkers and let AI predict your health future.</p>
                    <Link to="/input" className="btn-primary text-base px-10 py-3">
                        🧬 Start Analysis
                    </Link>
                </div>
            </section>

            <footer className="py-8 text-center text-slate-600 text-sm border-t border-blue-900/20">
                © 2025 BioClock · Powered by Amazon Bedrock Nova · Built for India 🇮🇳
            </footer>
        </div>
    )
}
