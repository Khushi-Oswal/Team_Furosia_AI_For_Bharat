import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../utils/auth.jsx'
import { useLanguage } from '../utils/i18n.jsx'
import { ingestPatient, parseReport, runETL, analyzePatient, translateText } from '../utils/api'
import { Navbar, ToastContainer, PageWrapper } from '../components/Layout'
import { toast } from '../utils/toast'

const INDIAN_CITIES = ['Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Chennai', 'Kolkata', 'Ahmedabad', 'Pune', 'Jaipur', 'Surat', 'Lucknow', 'Kanpur', 'Nagpur', 'Indore', 'Bhopal']

const BIOMARKER_FIELDS = [
    { key: 'hba1c', label: 'HbA1c', unit: '%', placeholder: '5.7', min: 3, max: 15, tier: 'Metabolic Markers' },
    { key: 'fasting_glucose', label: 'Fasting Glucose', unit: 'mg/dL', placeholder: '95', min: 50, max: 500, tier: 'Metabolic Markers' },
    { key: 'systolic_bp', label: 'Systolic BP', unit: 'mmHg', placeholder: '120', min: 80, max: 220, tier: 'Cardiovascular' },
    { key: 'diastolic_bp', label: 'Diastolic BP', unit: 'mmHg', placeholder: '80', min: 50, max: 140, tier: 'Cardiovascular' },
    { key: 'ldl', label: 'LDL Cholesterol', unit: 'mg/dL', placeholder: '100', min: 0, max: 400, tier: 'Cardiovascular' },
    { key: 'hdl', label: 'HDL Cholesterol', unit: 'mg/dL', placeholder: '60', min: 0, max: 120, tier: 'Cardiovascular' },
    { key: 'triglycerides', label: 'Triglycerides', unit: 'mg/dL', placeholder: '150', min: 0, max: 1000, tier: 'Cardiovascular' },
    { key: 'creatinine', label: 'Creatinine', unit: 'mg/dL', placeholder: '1.0', min: 0.1, max: 15, tier: 'Renal Markers' },
    { key: 'tsh', label: 'TSH', unit: 'mIU/L', placeholder: '2.0', min: 0.01, max: 50, tier: 'Hormonal Markers' },
    { key: 'vitamin_d', label: 'Vitamin D', unit: 'ng/mL', placeholder: '30', min: 0, max: 100, tier: 'Micronutrients' },
    { key: 'uric_acid', label: 'Uric Acid', unit: 'mg/dL', placeholder: '5.0', min: 1, max: 15, tier: 'Metabolic Markers' },
    { key: 'hemoglobin', label: 'Hemoglobin', unit: 'g/dL', placeholder: '14', min: 3, max: 20, tier: 'Hematology' },
]

const BY_TIER = BIOMARKER_FIELDS.reduce((acc, f) => { if (!acc[f.tier]) acc[f.tier] = []; acc[f.tier].push(f); return acc }, {})
const TIER_ICONS = { 'Metabolic Markers': '🍬', 'Cardiovascular': '❤️', 'Renal Markers': '🫘', 'Hormonal Markers': '⚗️', 'Micronutrients': '💊', 'Hematology': '🩸' }

export default function PatientInput() {
    const navigate = useNavigate()
    const { user } = useAuth()
    const { t, lang } = useLanguage()
    const [step, setStep] = useState(0)  // 0=choose method, 1=demographics, 2=biomarkers
    const [submitting, setSubmitting] = useState(false)
    const [parsing, setParsing] = useState(false)
    const [submittedPatientId, setSubmittedPatientId] = useState(null)
    const [analyzing, setAnalyzing] = useState(false)
    const [analysisResult, setAnalysisResult] = useState(null)
    const [translatedText, setTranslatedText] = useState(null)
    const [translatedLang, setTranslatedLang] = useState(null)
    const [reportText, setReportText] = useState('')
    const [aiExtraction, setAiExtraction] = useState(null)

    // Stable patient ID
    const patientId = useMemo(() => 'BIO' + Math.random().toString(36).substring(2, 10).toUpperCase(), [])

    const [form, setForm] = useState({
        patient_id: patientId,
        name: '', age: '', sex: '', bmi: '', city: '', smoking: false, family_history: false,
        biomarkers: {},
    })

    const setField = (key, val) => setForm((f) => ({ ...f, [key]: val }))
    const setBiomarker = (key, val) => setForm((f) => ({ ...f, biomarkers: { ...f.biomarkers, [key]: val } }))
    const canNextStep1 = form.name && form.age && form.sex

    // ═══ AI PDF/TEXT PARSING ═══
    const handleParseReport = async () => {
        if (!reportText || reportText.trim().length < 20) {
            toast.warning('Please paste your lab report text (at least 20 characters)')
            return
        }
        setParsing(true)
        setAiExtraction(null)
        try {
            const res = await parseReport({ report_text: reportText })
            const data = res.data
            setAiExtraction(data)

            // Auto-fill biomarkers
            const extracted = data.extracted_biomarkers || {}
            const newBiomarkers = {}
            let count = 0
            Object.entries(extracted).forEach(([key, val]) => {
                if (val !== null && val !== undefined) {
                    newBiomarkers[key] = String(val)
                    count++
                }
            })
            setForm(f => ({ ...f, biomarkers: { ...f.biomarkers, ...newBiomarkers } }))

            // Auto-fill patient info if available
            const info = data.patient_info || {}
            if (info.name) setField('name', info.name)
            if (info.age) setField('age', String(info.age))
            if (info.sex) setField('sex', info.sex)
            if (info.city) setField('city', info.city)

            toast.success(`AI extracted ${count} biomarkers from your report!`)
            setStep(1) // Go to demographics to review
        } catch (err) {
            toast.error('AI parsing failed: ' + (err?.response?.data?.error || err.message || 'Unknown error'))
        } finally {
            setParsing(false)
        }
    }

    const handleFileUpload = (e) => {
        const file = e.target.files[0]
        if (!file) return

        if (file.type === 'application/pdf') {
            // For PDF, read as text
            const reader = new FileReader()
            reader.onload = (ev) => {
                // Try to extract text from PDF (works for text-based PDFs)
                const text = ev.target.result
                if (text.length < 50) {
                    toast.warning('Could not read PDF. Please copy-paste the report text instead.')
                } else {
                    setReportText(text.substring(0, 8000))
                    toast.info('PDF loaded! Click "Extract Biomarkers" to analyze.')
                }
            }
            reader.readAsText(file)
        } else {
            // For txt files
            const reader = new FileReader()
            reader.onload = (ev) => {
                setReportText(ev.target.result.substring(0, 8000))
                toast.info('File loaded! Click "Extract Biomarkers" to analyze.')
            }
            reader.readAsText(file)
        }
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        const filledCount = Object.values(form.biomarkers).filter(v => v !== '').length
        if (filledCount < 3) {
            toast.warning('Please fill in at least 3 biomarker values.')
            return
        }
        setSubmitting(true)

        const payload = {
            patient_id: form.patient_id, name: form.name, age: Number(form.age),
            sex: form.sex, bmi: form.bmi ? Number(form.bmi) : undefined, city: form.city,
            smoker: form.smoking, family_history: form.family_history,
            source: aiExtraction ? 'ai_report_extraction' : 'manual_entry',
            user_id: user?.sub || user?.email || 'anonymous',
            user_email: user?.email || '',
            ...Object.fromEntries(Object.entries(form.biomarkers).filter(([,v]) => v !== '').map(([k,v]) => [k, Number(v)])),
        }

        try {
            const res = await ingestPatient(payload)
            const pid = res.data?.patient_id || form.patient_id
            // Run ETL silently in background (Bronze → Silver → Gold)
            try { await runETL(pid) } catch(e) { console.warn('ETL background:', e) }
            toast.success('Patient data submitted successfully! You can now run AI Analysis.')
            setSubmittedPatientId(pid)
            setStep(3) // Show success + analyze step
        } catch (err) {
            const status = err?.response?.status
            if (status === 409) {
                toast.info('Patient already exists.')
                setSubmittedPatientId(form.patient_id)
                setStep(3)
            } else {
                toast.error('Submission failed: ' + (err?.response?.data?.error || err.message))
            }
        } finally {
            setSubmitting(false)
        }
    }

    return (
        <div className="min-h-screen bg-grid">
            <Navbar /><ToastContainer />
            <PageWrapper>
                <div className="text-center mb-10 animate-fade-in">
                    <h1 className="text-4xl font-black gradient-text mb-2" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
                        {t('input.title')}
                    </h1>
                    <p className="text-slate-600">{t('input.subtitle')}</p>
                </div>

                {/* Step 0: Choose Input Method */}
                {step === 0 && (
                    <div className="max-w-3xl mx-auto space-y-6 animate-fade-in">
                        {/* Option 1: AI Upload */}
                        <div className="card" style={{ border: '2px solid rgba(59,130,246,0.3)' }}>
                            <div className="flex items-center gap-3 mb-4">
                                <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl" style={{ background: 'rgba(59,130,246,0.1)' }}>🤖</div>
                                <div>
                                    <h3 className="font-bold text-lg" style={{ color: '#1E40AF' }}>{t('input.uploadReport')}</h3>
                                    <p className="text-sm text-slate-600">Paste your pathology report text and AI will extract all biomarkers automatically</p>
                                </div>
                                <span className="ml-auto px-3 py-1 rounded-full text-xs font-bold" style={{ background: '#dbeafe', color: '#1E40AF' }}>RECOMMENDED</span>
                            </div>

                            <textarea
                                className="input-field mb-4"
                                rows={8}
                                placeholder="Paste your lab report text here...&#10;&#10;Example:&#10;Patient: Arjun Sharma, 45/M&#10;HbA1c: 6.8%&#10;Fasting Blood Sugar: 118 mg/dL&#10;Total Cholesterol: 220 mg/dL&#10;LDL: 145 mg/dL&#10;HDL: 38 mg/dL&#10;Triglycerides: 195 mg/dL&#10;Creatinine: 1.1 mg/dL&#10;TSH: 3.2 mIU/L&#10;Vitamin D: 18 ng/mL"
                                value={reportText}
                                onChange={(e) => setReportText(e.target.value)}
                            />

                            <div className="flex items-center gap-3 flex-wrap">
                                <label className="btn-secondary px-5 py-3 cursor-pointer">
                                    📄 {t('input.uploadReport')}
                                    <input type="file" accept=".txt,.pdf,.csv" className="hidden" onChange={handleFileUpload} />
                                </label>
                                <button className="btn-primary px-6 py-3" onClick={handleParseReport} disabled={parsing || !reportText}>
                                    {parsing ? '⏳ AI Extracting...' : '🧠 Extract Biomarkers with AI'}
                                </button>
                                {parsing && (
                                    <span className="text-sm text-slate-600 animate-pulse">Amazon Bedrock is reading your report...</span>
                                )}
                            </div>

                            {/* AI Extraction Result */}
                            {aiExtraction && (
                                <div className="mt-4 p-4 rounded-xl" style={{ background: '#f0fdf4', border: '1px solid #bbf7d0' }}>
                                    <p className="font-semibold text-sm mb-2" style={{ color: '#16a34a' }}>
                                        ✅ AI extracted {aiExtraction.biomarkers_found || Object.values(aiExtraction.extracted_biomarkers || {}).filter(v => v !== null).length} biomarkers
                                        {aiExtraction.confidence && <span className="ml-2 text-xs opacity-75">(confidence: {aiExtraction.confidence})</span>}
                                    </p>
                                    <div className="flex flex-wrap gap-2">
                                        {Object.entries(aiExtraction.extracted_biomarkers || {}).filter(([,v]) => v !== null).map(([k, v]) => (
                                            <span key={k} className="px-2 py-1 rounded text-xs font-medium" style={{ background: '#dcfce7', color: '#166534' }}>
                                                {k}: {v}
                                            </span>
                                        ))}
                                    </div>
                                    <p className="text-xs text-slate-600 mt-2">Model: {aiExtraction._model_used} · Powered by Amazon Bedrock</p>
                                </div>
                            )}
                        </div>

                        {/* Divider */}
                        <div className="flex items-center gap-4">
                            <div className="flex-1 h-px bg-slate-200"></div>
                            <span className="text-sm font-semibold text-slate-400">OR</span>
                            <div className="flex-1 h-px bg-slate-200"></div>
                        </div>

                        {/* Option 2: Manual Entry */}
                        <div className="card cursor-pointer" onClick={() => setStep(1)} style={{ border: '1px solid #e2e8f0' }}>
                            <div className="flex items-center gap-3">
                                <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl" style={{ background: '#f1f5f9' }}>✏️</div>
                                <div>
                                    <h3 className="font-bold text-lg text-slate-800">{ t('input.manualEntry') }</h3>
                                    <p className="text-sm text-slate-600">Type in biomarker values from your lab report manually</p>
                                </div>
                                <span className="ml-auto text-2xl text-slate-400">→</span>
                            </div>
                        </div>
                    </div>
                )}

                {/* Step indicator for steps 1-2 */}
                {step > 0 && (
                    <div className="flex items-center justify-center mb-8 gap-4">
                        {[{ n: 1, label: 'Demographics' }, { n: 2, label: 'Biomarkers' }].map(({ n, label }, i, arr) => (
                            <div key={n} className="flex items-center gap-3">
                                <div className="flex items-center gap-2">
                                    <div className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm"
                                        style={{ background: step >= n ? 'linear-gradient(135deg, #1E40AF, #3B82F6)' : 'rgba(59,130,246,0.1)', border: `2px solid ${step >= n ? '#3B82F6' : '#e2e8f0'}`, color: step >= n ? 'white' : '#64748b' }}>
                                        {step > n ? '✓' : n}
                                    </div>
                                    <span className={`text-sm font-medium ${step >= n ? 'text-slate-800' : 'text-slate-600'}`}>{label}</span>
                                </div>
                                {i < arr.length - 1 && <div className="w-16 h-0.5" style={{ background: step > 1 ? '#3B82F6' : '#e2e8f0' }} />}
                            </div>
                        ))}
                    </div>
                )}

                <form onSubmit={handleSubmit} className="max-w-3xl mx-auto">
                    {/* Step 1: Demographics */}
                    {step === 1 && (
                        <div className="card animate-fade-in">
                            <div className="flex items-center justify-between mb-6">
                                <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2"><span>👤</span> Patient Demographics</h2>
                                <button type="button" className="btn-secondary text-sm" onClick={() => setStep(0)}>← Back</button>
                            </div>
                            <div className="grid sm:grid-cols-2 gap-5">
                                <div>
                                    <label>Patient ID</label>
                                    <input className="input-field" value={form.patient_id} style={{ background: '#f1f5f9' }} readOnly />
                                </div>
                                <div>
                                    <label>Full Name *</label>
                                    <input className="input-field" placeholder="e.g. Arjun Sharma" required value={form.name} onChange={(e) => setField('name', e.target.value)} />
                                </div>
                                <div>
                                    <label>Age * (years)</label>
                                    <input className="input-field" type="number" placeholder="45" min={1} max={120} value={form.age} onChange={(e) => setField('age', e.target.value)} />
                                </div>
                                <div>
                                    <label>Biological Sex *</label>
                                    <select className="input-field" value={form.sex} onChange={(e) => setField('sex', e.target.value)}>
                                        <option value="">Select...</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                    </select>
                                </div>
                                <div>
                                    <label>BMI (kg/m²)</label>
                                    <input className="input-field" type="number" step="0.1" placeholder="22.5" min={10} max={60} value={form.bmi} onChange={(e) => setField('bmi', e.target.value)} />
                                </div>
                                <div>
                                    <label>City</label>
                                    <select className="input-field" value={form.city} onChange={(e) => setField('city', e.target.value)}>
                                        <option value="">Select city...</option>
                                        {INDIAN_CITIES.map(c => <option key={c} value={c}>{c}</option>)}
                                    </select>
                                </div>
                            </div>
                            <div className="flex gap-6 mt-5">
                                {[{ key: 'smoking', label: '🚬 Current Smoker' }, { key: 'family_history', label: '🧬 Family History' }].map(({ key, label }) => (
                                    <label key={key} className="flex items-center gap-2 cursor-pointer normal-case tracking-normal text-sm text-slate-700">
                                        <input type="checkbox" checked={form[key]} onChange={() => setField(key, !form[key])} className="w-4 h-4 accent-blue-600" />
                                        {label}
                                    </label>
                                ))}
                            </div>
                            <div className="flex justify-end mt-8">
                                <button type="button" className="btn-primary px-8" onClick={() => setStep(2)} disabled={!canNextStep1}>Next: Biomarkers →</button>
                            </div>
                        </div>
                    )}

                    {/* Step 2: Biomarkers */}
                    {step === 2 && (
                        <div className="space-y-6 animate-fade-in">
                            <div className="flex items-center justify-between">
                                <p className="text-slate-600 text-sm">
                                    {aiExtraction ? '🤖 AI-extracted values shown below. Review and edit if needed.' : 'Fill at least 3 biomarkers. Empty fields will be skipped.'}
                                </p>
                                <button type="button" className="btn-secondary text-sm" onClick={() => setStep(1)}>← Back</button>
                            </div>
                            {Object.entries(BY_TIER).map(([tier, fields]) => (
                                <div key={tier} className="card">
                                    <h3 className="font-semibold text-slate-800 mb-4 flex items-center gap-2"><span>{TIER_ICONS[tier]}</span>{tier}</h3>
                                    <div className="grid sm:grid-cols-2 gap-4">
                                        {fields.map(({ key, label, unit, placeholder, min, max }) => (
                                            <div key={key}>
                                                <label>{label} <span className="text-slate-600 normal-case">({unit})</span></label>
                                                <div className="relative">
                                                    <input className="input-field pr-14" type="number" step="0.01" placeholder={placeholder} min={min} max={max}
                                                        value={form.biomarkers[key] || ''} onChange={(e) => setBiomarker(key, e.target.value)}
                                                        style={form.biomarkers[key] && aiExtraction ? { background: '#f0fdf4', borderColor: '#86efac' } : {}}
                                                    />
                                                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-500">{unit}</span>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                            <div className="card">
                                <div className="flex items-center justify-between flex-wrap gap-4">
                                    <div>
                                        <p className="text-sm text-slate-700 font-medium">
                                            ✅ {Object.values(form.biomarkers).filter(v => v !== '').length} / {BIOMARKER_FIELDS.length} biomarkers filled
                                            {aiExtraction && <span className="ml-2 text-xs" style={{ color: '#1E40AF' }}>• AI-extracted</span>}
                                        </p>
                                        <p className="text-xs text-slate-600 mt-1">Patient: {form.name} · ID: {form.patient_id}</p>
                                    </div>
                                    <button type="submit" className="btn-primary px-8 py-3 text-base" disabled={submitting}>
                                        {submitting ? '⏳ Submitting...' : t('input.submitAnalyze')}
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Step 3: Success + Run Analysis */}
                    {step === 3 && submittedPatientId && (
                        <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
                            {/* Success Card */}
                            <div className="card text-center py-8" style={{ border: '2px solid #86efac' }}>
                                <div className="text-5xl mb-4">✅</div>
                                <h2 className="text-2xl font-bold text-slate-800 mb-2">{t('input.submitted')}</h2>
                                <p className="text-slate-600 mb-1">Patient ID: <span className="font-mono font-bold" style={{ color: '#1E40AF' }}>{submittedPatientId}</span></p>
                                <p className="text-slate-500 text-sm">Data ingested → ETL pipeline completed → Ready for AI analysis</p>
                            </div>

                            {/* Analysis Card */}
                            {!analysisResult ? (
                                <div className="card text-center py-8">
                                    <div className="text-4xl mb-4">🧠</div>
                                    <h3 className="text-xl font-bold text-slate-800 mb-2">Run AI Analysis</h3>
                                    <p className="text-slate-600 text-sm mb-6">
                                        Trigger the 4-agent Amazon Bedrock analysis chain to predict disease risk
                                    </p>
                                    <button
                                        className="btn-primary px-10 py-4 text-lg"
                                        onClick={async () => {
                                            setAnalyzing(true)
                                            try {
                                                const res = await analyzePatient(submittedPatientId)
                                                const data = res.data
                                                setAnalysisResult(data)
                                                toast.success(t('common.analysisComplete') + '!')

                                                // Auto-translate AI responses if language is not English
                                                if (lang !== 'en' && data.reasoning) {
                                                    toast.info('Translating results to ' + lang + '...')
                                                    try {
                                                        const tr = translateText
                                                        const translated = { ...data.reasoning }
                                                        const translatedPreds = [...(data.predictions || [])]

                                                        // Translate each agent's reasoning
                                                        for (const key of ['agent1', 'agent2', 'agent3', 'agent4', 'supervisor']) {
                                                            if (translated[key]) {
                                                                try {
                                                                    const r = await tr(translated[key].substring(0, 2000), lang)
                                                                    translated[key] = r.data?.translated_text || translated[key]
                                                                } catch { /* keep English */ }
                                                            }
                                                        }

                                                        // Translate prediction evidence
                                                        for (let i = 0; i < translatedPreds.length; i++) {
                                                            if (translatedPreds[i].evidence) {
                                                                try {
                                                                    const r = await tr(translatedPreds[i].evidence.substring(0, 1000), lang)
                                                                    translatedPreds[i] = { ...translatedPreds[i], evidence: r.data?.translated_text || translatedPreds[i].evidence }
                                                                } catch { /* keep English */ }
                                                            }
                                                        }

                                                        // Translate supervisor reason
                                                        if (data.supervisor?.reason) {
                                                            try {
                                                                const r = await tr(data.supervisor.reason.substring(0, 1000), lang)
                                                                data.supervisor = { ...data.supervisor, reason: r.data?.translated_text || data.supervisor.reason }
                                                            } catch { /* keep English */ }
                                                        }

                                                        setAnalysisResult({ ...data, reasoning: translated, predictions: translatedPreds })
                                                        toast.success('Results translated!')
                                                    } catch (trErr) {
                                                        console.warn('Translation failed:', trErr)
                                                    }
                                                }
                                            } catch (err) {
                                                toast.error('Analysis failed: ' + (err.message || 'Unknown error'))
                                            } finally {
                                                setAnalyzing(false)
                                            }
                                        }}
                                        disabled={analyzing}
                                    >
                                        {analyzing ? '⏳ AI Agents Processing...' : t('input.runAnalysis')}
                                    </button>
                                    {analyzing && (
                                        <div className="mt-6 space-y-4">
                                            <div className="flex items-center justify-center gap-2 flex-wrap">
                                                {[
                                                    { name: 'Agent 1', label: 'Temporal', icon: '📈' },
                                                    { name: 'Agent 2', label: 'Correlator', icon: '🔗' },
                                                    { name: 'Agent 3', label: 'Trajectory', icon: '🔮' },
                                                    { name: 'Agent 4', label: 'Intervention', icon: '💊' },
                                                ].map((agent, i) => (
                                                    <div key={i} className="flex items-center gap-1">
                                                        <div className="flex flex-col items-center px-3 py-2 rounded-lg text-center"
                                                            style={{
                                                                background: '#eff6ff',
                                                                border: '1px solid #bfdbfe',
                                                                animation: `fadeInAgent 0.5s ease ${i * 0.8}s both`
                                                            }}>
                                                            <span className="text-lg">{agent.icon}</span>
                                                            <span className="text-xs font-bold text-slate-700">{agent.name}</span>
                                                            <span className="text-xs text-slate-500">{agent.label}</span>
                                                        </div>
                                                        {i < 3 && <span className="text-slate-300 text-lg">→</span>}
                                                    </div>
                                                ))}
                                            </div>
                                            <p className="text-sm text-center text-slate-500 animate-pulse">
                                                Amazon Bedrock Nova is analyzing biomarkers...
                                            </p>
                                        </div>
                                    )}
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    {/* Analysis Complete Banner */}
                                    <div className="card" style={{ border: '2px solid #86efac', background: '#f0fdf4' }}>
                                        <div className="flex items-center gap-3">
                                            <span className="text-2xl">✅</span>
                                            <div>
                                                <p className="font-bold" style={{ color: '#16a34a' }}>AI Analysis Complete</p>
                                                <p className="text-xs text-slate-600">
                                                    {analysisResult.agents_run} agents · {analysisResult.elapsed_seconds}s · Risk: <span className="font-bold">{analysisResult.overall_risk?.toUpperCase()}</span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Disease Predictions with Evidence */}
                                    {analysisResult.predictions?.length > 0 && (
                                        <div className="card">
                                            <p className="font-bold text-base mb-4 text-slate-800">🎯 {t('common.diseasePredictions')}</p>
                                            <div className="space-y-4">
                                                {analysisResult.predictions.map((p, i) => (
                                                    <div key={i} className="p-4 rounded-xl" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                                                        <div className="flex items-center justify-between mb-2">
                                                            <p className="font-bold text-slate-800">{p.disease}</p>
                                                            <span className="text-sm font-bold px-3 py-1 rounded-full" style={{
                                                                background: p.probability_5yr > 60 ? '#fef2f2' : p.probability_5yr > 30 ? '#fffbeb' : '#f0fdf4',
                                                                color: p.probability_5yr > 60 ? '#dc2626' : p.probability_5yr > 30 ? '#d97706' : '#16a34a',
                                                                border: `1px solid ${p.probability_5yr > 60 ? '#fecaca' : p.probability_5yr > 30 ? '#fde68a' : '#bbf7d0'}`
                                                            }}>
                                                                {p.probability_5yr}% in 5 years
                                                            </span>
                                                        </div>
                                                        {/* Timeline */}
                                                        <div className="flex gap-4 text-xs mb-3">
                                                            <span className="text-slate-500">1yr: <b>{p.probability_1yr}%</b></span>
                                                            <span className="text-slate-500">3yr: <b>{p.probability_3yr}%</b></span>
                                                            <span className="text-slate-500">5yr: <b>{p.probability_5yr}%</b></span>
                                                            <span className="text-slate-500">10yr: <b>{p.probability_10yr}%</b></span>
                                                        </div>
                                                        {/* Progress bar */}
                                                        <div className="w-full h-2 rounded-full mb-3" style={{ background: '#e2e8f0' }}>
                                                            <div className="h-2 rounded-full transition-all" style={{ width: `${p.probability_5yr}%`, background: p.probability_5yr > 60 ? '#dc2626' : p.probability_5yr > 30 ? '#f59e0b' : '#10B981' }} />
                                                        </div>
                                                        {/* Evidence / Reasoning */}
                                                        {p.evidence && (
                                                            <div className="text-xs text-slate-600 mb-2 p-2 rounded" style={{ background: '#f1f5f9' }}>
                                                                <b>Why:</b> {p.evidence}
                                                            </div>
                                                        )}
                                                        <p className="text-xs text-slate-500">{t('common.keyDrivers')}: <b>{(p.key_drivers || []).join(', ')}</b></p>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    )}

                                    {/* Intervention Plan - Always show prominently */}
                                    {analysisResult.reasoning?.agent4 && (
                                        <div className="card" style={{ border: '2px solid #86efac', background: '#f0fdf4' }}>
                                            <p className="font-bold text-base mb-3" style={{ color: '#16a34a' }}>💊 {t('common.interventionPlan')}</p>
                                            <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">{analysisResult.reasoning.agent4}</p>
                                        </div>
                                    )}

                                    {/* Agent Reasoning Summary */}
                                    <div className="card">
                                        <p className="font-bold text-base mb-3 text-slate-800">🔍 {t('common.agentReasoning')}</p>
                                        <div className="space-y-3">
                                            {[
                                                { key: 'agent1', label: t('common.temporalAnalysis'), icon: '📈' },
                                                { key: 'agent2', label: t('common.biomarkerCorrelations'), icon: '🔗' },
                                                { key: 'agent3', label: t('common.diseaseTrajectory'), icon: '🔮' },
                                            ].map(({ key, label, icon }) => {
                                                const text = analysisResult.reasoning?.[key]
                                                if (!text) return null
                                                return (
                                                    <div key={key} className="p-3 rounded-lg" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                                                        <p className="font-semibold text-xs text-slate-600 mb-1">{icon} {label}</p>
                                                        <p className="text-sm text-slate-700 leading-relaxed">{text}</p>
                                                    </div>
                                                )
                                            })}
                                        </div>
                                    </div>

                                    {/* Navigation buttons */}
                                    <div className="flex gap-3 justify-center pt-4">
                                        <button className="btn-secondary px-6 py-3" onClick={() => navigate(`/patient/${submittedPatientId}`)}>
                                            📊 {t('common.viewPatient')}
                                        </button>
                                        <button className="btn-secondary px-6 py-3" onClick={() => navigate('/dashboard')}>
                                            📋 {t('common.goToDashboard')}
                                        </button>
                                        <button className="btn-primary px-6 py-3" onClick={() => { setStep(0); setSubmittedPatientId(null); setAnalysisResult(null); setForm(f => ({...f, patient_id: 'BIO' + Math.random().toString(36).substring(2,10).toUpperCase(), biomarkers: {}})) }}>
                                            ➕ {t('common.newPatient')}
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </form>
            </PageWrapper>
        </div>
    )
}
