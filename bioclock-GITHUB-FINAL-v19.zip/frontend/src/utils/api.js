import axios from 'axios'
import { getIdToken } from './auth.jsx'

const BASE_URL = 'https://y7b54ovc80.execute-api.ap-south-1.amazonaws.com/Dev'
const ANALYZE_URL = 'https://t3leaohmpnrhdqrmsqhvbibhna0lvkai.lambda-url.ap-south-1.on.aws'

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
  timeout: 60000,
})

api.interceptors.request.use(async (config) => {
  try {
    const token = await getIdToken()
    if (token) config.headers.Authorization = token
  } catch (err) {
    console.warn('Could not get auth token:', err)
  }
  return config
})

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) window.location.href = '/login'
    return Promise.reject(error)
  }
)

export const ingestPatient = (data) => api.post('/api/ingest', data)
export const runETL = (patientId) => api.post('/api/etl', { patient_id: patientId })
export const getPatients = (userId) => api.get('/api/patients', { params: { user_id: userId } })
export const getPredictions = (userId) => api.get(`/api/predictions/${userId}`)
export const getReasoning = (sessionId) => api.get(`/api/reasoning/${sessionId}`)
export const translateText = (text, targetLanguage) =>
  api.post('/api/translate', { text, target_language: targetLanguage })
export const parseReport = (data) => api.post('/api/parse-report', data)

export const analyzePatient = (patientId) =>
  axios.post(ANALYZE_URL, { patient_id: patientId }, {
    headers: { 'Content-Type': 'application/json' },
    timeout: 300000
  })

export default api
