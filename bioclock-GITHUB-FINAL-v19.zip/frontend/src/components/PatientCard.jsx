import { Link } from 'react-router-dom'
import { RiskBadge } from './Layout'

export function PatientCard({ patient, index = 0 }) {
    const { patient_id, name, age, sex, city, overall_risk, biomarkers_count, created_at } = patient

    return (
        <Link
            to={`/patient/${patient_id}`}
            className="card glass-hover block no-underline"
            style={{ animationDelay: `${index * 60}ms` }}
        >
            <div className="flex items-start justify-between mb-4">
                {/* Avatar */}
                <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full flex items-center justify-center font-bold text-lg"
                        style={{ background: 'linear-gradient(135deg, #1E40AF, #7C3AED)', color: 'white' }}>
                        {(name || 'P').charAt(0).toUpperCase()}
                    </div>
                    <div>
                        <h3 className="font-bold text-slate-800 text-base leading-tight">{name || 'Unknown Patient'}</h3>
                        <p className="text-xs text-slate-400 mt-0.5 font-mono">{patient_id}</p>
                    </div>
                </div>
                <RiskBadge risk={overall_risk} size="sm" />
            </div>

            {/* Info grid */}
            <div className="grid grid-cols-3 gap-3 mb-4">
                {[
                    { label: 'Age', value: age ? `${age}y` : '—' },
                    { label: 'Sex', value: sex || '—' },
                    { label: 'City', value: city || '—' },
                ].map(({ label, value }) => (
                    <div key={label} className="text-center rounded-lg py-2"
                        style={{ background: 'rgba(59,130,246,0.05)', border: '1px solid rgba(30,64,175,0.15)' }}>
                        <p className="text-xs text-slate-500 mb-0.5">{label}</p>
                        <p className="text-sm font-semibold text-slate-700 truncate">{value}</p>
                    </div>
                ))}
            </div>

            <div className="flex items-center justify-between text-xs text-slate-500">
                <span>🧾 {biomarkers_count ?? '—'} biomarkers</span>
                {created_at && <span>📅 {new Date(created_at).toLocaleDateString('en-IN')}</span>}
                <span className="text-blue-400 font-medium">View →</span>
            </div>
        </Link>
    )
}

export function StatCard({ icon, label, value, color = '#60a5fa', sub }) {
    return (
        <div className="card" style={{ borderLeft: `3px solid ${color}` }}>
            <div className="flex items-center gap-3 mb-2">
                <span className="text-2xl">{icon}</span>
                <span className="text-xs text-slate-500 uppercase tracking-wide font-medium">{label}</span>
            </div>
            <p className="text-3xl font-bold" style={{ color }}>{value}</p>
            {sub && <p className="text-xs text-slate-500 mt-1">{sub}</p>}
        </div>
    )
}
