"""
BioClock Glue Job 2: Silver ETL (Bronze Parquet → Silver Parquet)
Source: s3://bioclock-health-data/bronze-parquet/
Output: s3://bioclock-health-data/silver-parquet/
Partitioned by: overall_risk (high/moderate/low)
Adds: 7 risk flags, metabolic syndrome score, Indian reference ranges
"""

import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

BUCKET = "bioclock-health-data"
SOURCE_PATH = f"s3://{BUCKET}/bronze-parquet/"
OUTPUT_PATH = f"s3://{BUCKET}/silver-parquet/"

# Read Bronze Parquet
df = spark.read.parquet(SOURCE_PATH)

# ═══ INDIAN POPULATION REFERENCE RANGES ═══
# Cast biomarker columns to double
biomarker_cols = ['hba1c', 'fasting_glucose', 'systolic_bp', 'diastolic_bp',
                  'ldl_cholesterol', 'hdl_cholesterol', 'triglycerides',
                  'creatinine', 'tsh', 'vitamin_d', 'uric_acid', 'hemoglobin', 'bmi']

for col_name in biomarker_cols:
    if col_name in df.columns:
        df = df.withColumn(col_name, col(col_name).cast("double"))

# ═══ RISK FLAG COMPUTATION (Indian Criteria) ═══

# 1. Diabetes Risk (Indian cutoffs: BMI > 23, HbA1c > 5.7)
df = df.withColumn("flag_diabetes_risk",
    when((col("hba1c") >= 5.7) | (col("fasting_glucose") >= 100), 1).otherwise(0)
)

# 2. Cardiovascular Risk
df = df.withColumn("flag_cvd_risk",
    when((col("ldl_cholesterol") >= 100) | (col("hdl_cholesterol") < 40) |
         (col("systolic_bp") >= 130) | (col("triglycerides") >= 150), 1).otherwise(0)
)

# 3. Inflammation / Metabolic
df = df.withColumn("flag_inflammation",
    when((col("triglycerides") >= 200) & (col("hdl_cholesterol") < 40), 1).otherwise(0)
)

# 4. Kidney Risk
df = df.withColumn("flag_kidney_risk",
    when((col("creatinine") >= 1.3) | (col("uric_acid") >= 7.0), 1).otherwise(0)
)

# 5. Thyroid Risk
df = df.withColumn("flag_thyroid",
    when(col("tsh") >= 4.0, 1).otherwise(0)
)

# 6. Liver Risk (NAFLD indicator)
df = df.withColumn("flag_liver_risk",
    when((col("bmi") >= 23) & (col("triglycerides") >= 150), 1).otherwise(0)
)

# 7. Metabolic Syndrome (Indian criteria: 3 of 5)
df = df.withColumn("met_syn_bmi", when(col("bmi") >= 23, 1).otherwise(0)) \
       .withColumn("met_syn_tg", when(col("triglycerides") >= 150, 1).otherwise(0)) \
       .withColumn("met_syn_hdl", when(col("hdl_cholesterol") < 40, 1).otherwise(0)) \
       .withColumn("met_syn_bp", when(col("systolic_bp") >= 130, 1).otherwise(0)) \
       .withColumn("met_syn_fg", when(col("fasting_glucose") >= 100, 1).otherwise(0))

df = df.withColumn("metabolic_syndrome_score",
    col("met_syn_bmi") + col("met_syn_tg") + col("met_syn_hdl") + col("met_syn_bp") + col("met_syn_fg")
)

df = df.withColumn("flag_metabolic_syndrome",
    when(col("metabolic_syndrome_score") >= 3, 1).otherwise(0)
)

# ═══ OVERALL RISK CLASSIFICATION ═══
df = df.withColumn("total_flags",
    col("flag_diabetes_risk") + col("flag_cvd_risk") + col("flag_inflammation") +
    col("flag_kidney_risk") + col("flag_thyroid") + col("flag_liver_risk") + col("flag_metabolic_syndrome")
)

df = df.withColumn("overall_risk",
    when(col("total_flags") >= 4, "high")
    .when(col("total_flags") >= 2, "moderate")
    .otherwise("low")
)

# Add audit columns
df = df.withColumn("_cleaned_at", lit(datetime.utcnow().isoformat())) \
       .withColumn("_layer", lit("silver"))

# Drop temp columns
df = df.drop("met_syn_bmi", "met_syn_tg", "met_syn_hdl", "met_syn_bp", "met_syn_fg")

# Write Silver Parquet (partitioned by risk level)
df.write.mode("overwrite") \
    .partitionBy("overall_risk") \
    .parquet(OUTPUT_PATH)

print(f"Silver ETL complete. Records: {df.count()}")
print(f"Risk distribution: {df.groupBy('overall_risk').count().collect()}")
job.commit()
