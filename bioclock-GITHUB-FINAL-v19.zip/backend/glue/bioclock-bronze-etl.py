"""
BioClock Glue Job 1: Bronze ETL (CSV → Bronze Parquet)
Source: s3://bioclock-health-data/knowledge/sample_biological_data.csv
Output: s3://bioclock-health-data/bronze-parquet/
Partitioned by: _ingest_year, _ingest_month
"""

import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

BUCKET = "bioclock-health-data"
SOURCE_PATH = f"s3://{BUCKET}/knowledge/sample_biological_data.csv"
OUTPUT_PATH = f"s3://{BUCKET}/bronze-parquet/"

# Read CSV
df = spark.read.option("header", "true").option("inferSchema", "true").csv(SOURCE_PATH)

# Add audit columns
df = df.withColumn("_ingested_at", lit(datetime.utcnow().isoformat())) \
       .withColumn("_source", lit("csv_knowledge_base")) \
       .withColumn("_layer", lit("bronze")) \
       .withColumn("_record_id", monotonically_increasing_id()) \
       .withColumn("_dq_flag", lit("raw")) \
       .withColumn("_ingest_year", lit(datetime.utcnow().year)) \
       .withColumn("_ingest_month", lit(datetime.utcnow().month))

# Deduplicate by patient_id (keep latest)
if "patient_id" in df.columns:
    df = df.dropDuplicates(["patient_id"])

# Write as Parquet (partitioned)
df.write.mode("overwrite") \
    .partitionBy("_ingest_year", "_ingest_month") \
    .parquet(OUTPUT_PATH)

print(f"Bronze ETL complete. Records: {df.count()}, Columns: {len(df.columns)}")
job.commit()
