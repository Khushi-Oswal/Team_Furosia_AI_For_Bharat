"""
BioClock Glue Job 3: Gold ETL (Silver Parquet → Gold Parquet)
Source: s3://bioclock-health-data/silver-parquet/
Output: s3://bioclock-health-data/gold-parquet/
Adds: risk_score (0-100), disease_prediction_label, population analytics
"""

import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime

args = getResolvedOptions(sys.argv, ['JOB_NAME'])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

BUCKET = "bioclock-health-data"
SOURCE_PATH = f"s3://{BUCKET}/silver-parquet/"
OUTPUT_PATH = f"s3://{BUCKET}/gold-parquet/"

# Read Silver Parquet
df = spark.read.parquet(SOURCE_PATH)

# ═══ RISK SCORE CALCULATION (0-100) ═══
# Weighted scoring based on Indian disease burden priorities
df = df.withColumn("risk_score",
    (col("flag_diabetes_risk") * 25) +        # Diabetes: highest burden in India
    (col("flag_cvd_risk") * 25) +             # CVD: #1 killer
    (col("flag_inflammation") * 15) +          # Atherogenic dyslipidemia
    (col("flag_kidney_risk") * 20) +           # CKD rising in India
    (col("flag_metabolic_syndrome") * 15)      # Metabolic syndrome
)

# ═══ DISEASE PREDICTION LABELS ═══
df = df.withColumn("disease_prediction",
    when((col("hba1c") >= 6.5) | (col("fasting_glucose") >= 126), "Diabetes")
    .when((col("hba1c") >= 5.7) | (col("fasting_glucose") >= 100), "Pre-Diabetes")
    .when((col("flag_cvd_risk") == 1) & (col("flag_inflammation") == 1), "Cardiovascular Disease")
    .when(col("flag_metabolic_syndrome") == 1, "Metabolic Syndrome")
    .otherwise("Healthy")
)

# ═══ RISK TIER (for population analytics) ═══
df = df.withColumn("risk_tier",
    when(col("risk_score") >= 80, "Critical")
    .when(col("risk_score") >= 60, "High")
    .when(col("risk_score") >= 30, "Moderate")
    .when(col("risk_score") >= 10, "Low")
    .otherwise("Minimal")
)

# ═══ AGE GROUP (for demographic analysis) ═══
if "age" in df.columns:
    df = df.withColumn("age_group",
        when(col("age") < 30, "18-29")
        .when(col("age") < 40, "30-39")
        .when(col("age") < 50, "40-49")
        .when(col("age") < 60, "50-59")
        .otherwise("60+")
    )

# Add audit columns
df = df.withColumn("_gold_processed_at", lit(datetime.utcnow().isoformat())) \
       .withColumn("_layer", lit("gold"))

# Write Gold Parquet
df.write.mode("overwrite").parquet(OUTPUT_PATH)

print(f"Gold ETL complete. Records: {df.count()}")
print(f"Disease predictions: {df.groupBy('disease_prediction').count().collect()}")
print(f"Risk tiers: {df.groupBy('risk_tier').count().collect()}")
job.commit()
