"""
BioClock Agent 1: Temporal Pattern Analyzer (Enhanced Prompts v2)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Features: Retry + Model Fallback + S3 Cache + Deep RAG Context
"""

import json
import boto3
import os
import time
from datetime import datetime

s3 = boto3.client('s3')
BUCKET = os.environ.get('BUCKET_NAME', 'bioclock-health-data')
BEDROCK_REGION = os.environ.get('BEDROCK_REGION', 'us-east-1')
bedrock = boto3.client(service_name='bedrock-runtime', region_name=BEDROCK_REGION)

MODEL_CHAIN = [
    os.environ.get('BEDROCK_MODEL_ID', 'amazon.nova-lite-v1:0'),
    'amazon.nova-pro-v1:0',
]

RAG_CONTEXT = """
=== INDIAN POPULATION BIOMARKER REFERENCE RANGES (ICMR 2023 + API Guidelines) ===

METABOLIC TIER:
  HbA1c: Normal <5.7%, Pre-diabetic 5.7-6.4%, Diabetic ≥6.5%
    - CRITICAL: Indians develop Type 2 Diabetes at BMI 23+ (not 30+ like Western populations)
    - Rate alarm: Rising >0.1%/month = rapid deterioration (needs Metformin discussion)
    - Rate alarm: Rising 0.05-0.1%/month = lifestyle intervention window (3-6 month opportunity)
    - Example: Patient Arjun, 42M Mumbai, HbA1c went 5.4→5.6→5.8→6.1 over 18 months. Rate = +0.04%/month.
      At this rate, crosses 6.5% (diabetic) in ~10 months. INTERVENTION WINDOW: 10 months.
    - Example: Patient Priya, 35F Bangalore, HbA1c stable at 5.2 for 3 years = LOW RISK, skip deeper analysis.

  Fasting Glucose: Normal 70-100, Pre-diabetic 100-125, Diabetic ≥126 mg/dL
    - Rate alarm: Rising >3 mg/dL/month = concerning upward trend
    - INDIA-SPECIFIC: Post-prandial glucose is more predictive for Indians (rice-heavy diet causes spikes)
    - Example: Glucose 95→102→108→115 over 4 readings = +5/month, will cross 126 in ~2 months

CARDIOVASCULAR TIER:
  Systolic BP: Normal <120, Elevated 120-129, Stage1 130-139, Stage2 ≥140 mmHg
    - Rate alarm: Rising >2 mmHg/month = hypertensive trajectory
    - INDIA-SPECIFIC: Salt intake 9.5g/day (WHO recommends <5g). Pickles, papad, processed snacks are major contributors.
    - Example: BP 122→126→132→138 over 6 months = +2.7/month. Will cross 140 (Stage 2) in <1 month.

  Diastolic BP: Normal <80, Elevated 80-89, Hypertension ≥90 mmHg

  LDL Cholesterol: Optimal <100, Near-optimal 100-129, Borderline 130-159, High 160-189 mg/dL
    - INDIA-SPECIFIC: Indians have smaller, denser LDL particles (more atherogenic at same LDL number)
    - Rate alarm: Rising >3 mg/dL/month = increasing atherosclerotic risk
    - JAPI study: Indian LDL target should be <100 for all adults (not <130 as in Western guidelines)

  HDL Cholesterol: Low <40(men)/<50(women), Normal 40-60, Optimal >60 mg/dL
    - Rate alarm: Falling >1 mg/dL/month = worsening cardiovascular protection
    - INDIA-SPECIFIC: Average Indian HDL is 37-43 mg/dL (among lowest globally)
    - Low HDL + High TG = Atherogenic Dyslipidemia (the #1 lipid abnormality in Indians)

  Triglycerides: Normal <150, Borderline 150-199, High 200-499, Very High ≥500 mg/dL
    - INDIA-SPECIFIC: Carbohydrate-heavy diet (rice, roti, sugar in chai) drives TG elevation
    - TG/HDL ratio >3.5 = strong predictor of insulin resistance in South Asians

RENAL TIER:
  Creatinine: Normal 0.6-1.2(men)/0.5-1.1(women) mg/dL
    - Rate alarm: Rising >0.05 mg/dL/year = early renal decline (may indicate CKD Stage 1-2)
    - INDIA-SPECIFIC: Leading cause of CKD in India is uncontrolled diabetes + hypertension
    - Example: Creatinine 1.0→1.1→1.3→1.5 over 2 years = urgent nephrology referral

  Uric Acid: Normal 3.5-7.2(men)/2.6-6.0(women) mg/dL
    - Elevated uric acid predicts gout AND cardiovascular events
    - INDIA-SPECIFIC: Non-vegetarian food consumption in India is rising → uric acid increasing

THYROID TIER:
  TSH: Normal 0.4-4.0, Subclinical hypothyroid 4-10, Overt hypothyroid >10 mIU/L
    - 11% of Indians have thyroid disorders (higher in women, coastal populations)
    - Subclinical hypothyroid → weight gain → insulin resistance → metabolic syndrome cascade
    - Rate: TSH rising >0.5 mIU/L/year = subclinical hypothyroid progression

MICRONUTRIENT TIER:
  Vitamin D: Sufficient ≥30, Insufficient 20-29, Deficient <20 ng/mL
    - 70-80% of urban Indians are Vitamin D deficient DESPITE tropical climate (indoor lifestyle, pollution, dark skin)
    - Vitamin D deficiency → insulin resistance → increased diabetes risk
    - Vitamin D deficiency → bone loss → osteoporosis (especially post-menopausal Indian women)

  Hemoglobin: Normal 13-17(men)/12-16(women) g/dL
    - Anemia affects 50% of Indian women and 25% of Indian men
    - Iron deficiency anemia: Hb <11 + low ferritin
    - B12 deficiency anemia: Hb <12 + low B12 (47% of vegetarian Indians)
    - Chronic disease anemia: Hb declining with rising creatinine = renal anemia

=== TEMPORAL ANALYSIS METHODOLOGY ===
1. Calculate rate of change: (latest_value - earliest_value) / time_period_months
2. Determine acceleration: Is the rate itself increasing (curve bending upward)?
3. Threshold proximity: How many months until the value crosses a clinical threshold?
4. Pattern recognition: Which combination of trends suggests a specific disease trajectory?
5. Indian calibration: Apply Indian-specific thresholds (BMI 23, LDL <100, etc.)

=== RECOMMENDATION LOGIC ===
If ALL biomarkers are normal AND stable AND no acceleration → recommendation: "SKIP_REMAINING", risk_level: "low"
If ANY biomarker is borderline OR has concerning rate of change → recommendation: "CONTINUE", risk_level: "moderate"
If ANY biomarker is abnormal OR multiple borderlines → recommendation: "CONTINUE", risk_level: "high"
If MULTIPLE biomarkers critical OR rapid deterioration → recommendation: "CONTINUE", risk_level: "critical"
"""

SYSTEM_PROMPT = f"""You are Agent 1: Temporal Pattern Analyzer for BioClock, an AI health prediction system specifically designed for the Indian population.

{RAG_CONTEXT}

YOUR TASK: Analyze temporal trends in the patient's biomarker data. For each biomarker:
1. Calculate rate of change per month
2. Determine if the trend is accelerating, decelerating, or constant
3. Calculate how many months until the value crosses a clinical threshold
4. Identify which trends are most clinically concerning
5. Apply Indian-specific reference ranges (BMI 23 cutoff, LDL <100 target, etc.)

IMPORTANT RULES:
- Use INDIAN reference ranges, not Western ones
- If you only have ONE data point per biomarker (no time series), still analyze the static values against thresholds and note the status
- Be specific about threshold proximity: "HbA1c at 6.1% is 0.4% below diabetic threshold of 6.5%"
- Include clinical significance for each finding
- Give a clear recommendation: SKIP_REMAINING (for low-risk, stable patients) or CONTINUE (for patients needing deeper analysis)

RESPOND ONLY WITH VALID JSON (no markdown, no backticks, no explanation outside JSON):
{{
  "agent": "temporal_pattern_analyzer",
  "risk_level": "low|moderate|high|critical",
  "summary": "3-4 sentence clinical summary of temporal findings with specific numbers",
  "biomarker_trends": [
    {{
      "biomarker": "hba1c",
      "current_value": 6.8,
      "unit": "%",
      "first_value": 6.8,
      "rate_of_change": "0.15% per month",
      "trend": "rising|falling|stable",
      "acceleration": "accelerating|decelerating|constant",
      "status": "normal|borderline|abnormal|critical",
      "threshold_proximity": "Already past diabetic threshold of 6.5%",
      "clinical_significance": "Confirms diabetes. HbA1c at 6.8% indicates average blood glucose ~148 mg/dL over past 3 months. Immediate pharmacological intervention (Metformin) recommended per ICMR guidelines."
    }}
  ],
  "critical_alerts": ["HbA1c 6.8% = confirmed diabetes per ICMR criteria", "Systolic BP 142 mmHg = Stage 2 Hypertension"],
  "time_to_threshold": [
    {{
      "biomarker": "hba1c",
      "threshold": "diabetic threshold 6.5%",
      "estimated_months": 0,
      "confidence": "high"
    }}
  ],
  "recommendation": "CONTINUE|SKIP_REMAINING"
}}"""


def respond(code, body):
    return {
        'statusCode': code,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps(body)
    }


def call_bedrock_with_retry(prompt, system_prompt, max_retries=3):
    last_error = None
    for model_id in MODEL_CHAIN:
        for attempt in range(max_retries):
            try:
                body = json.dumps({
                    "messages": [{"role": "user", "content": [{"text": prompt}]}],
                    "system": [{"text": system_prompt}],
                    "inferenceConfig": {"maxTokens": 4000, "temperature": 0.2, "topP": 0.9}
                })
                response = bedrock.invoke_model(modelId=model_id, body=body, contentType="application/json", accept="application/json")
                result = json.loads(response['body'].read())
                text = result['output']['message']['content'][0]['text']
                text = text.strip()
                if text.startswith('```'): text = text.split('\n', 1)[1].rsplit('```', 1)[0]
                return json.loads(text), model_id
            except Exception as e:
                last_error = e
                print(f"Model {model_id} attempt {attempt+1} failed: {e}")
                if attempt < max_retries - 1: time.sleep(2 * (attempt + 1))
    raise last_error


def get_cached_result(patient_id, agent_name):
    try:
        key = f"cache/agents/{agent_name}/{patient_id}.json"
        obj = s3.get_object(Bucket=BUCKET, Key=key)
        data = json.loads(obj['Body'].read())
        data['_source'] = 'cache'
        return data
    except: return None


def cache_result(patient_id, agent_name, result):
    try:
        key = f"cache/agents/{agent_name}/{patient_id}.json"
        s3.put_object(Bucket=BUCKET, Key=key, Body=json.dumps(result, indent=2), ContentType='application/json')
    except: pass


def save_session(patient_id, agent_name, result):
    try:
        ts = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        key = f"agent-sessions/{patient_id}/{agent_name}/{ts}.json"
        s3.put_object(Bucket=BUCKET, Key=key, Body=json.dumps(result, indent=2), ContentType='application/json')
    except: pass


def rule_based_fallback(gold_data):
    """Emergency rule-based analysis if all models fail"""
    trends = gold_data.get('biomarker_trends', {})
    risk_score = 0
    alerts = []

    checks = {
        'hba1c': {'danger': 6.5, 'warn': 5.7, 'msg': 'Diabetic HbA1c', 'wmsg': 'Pre-diabetic HbA1c'},
        'fasting_glucose': {'danger': 126, 'warn': 100, 'msg': 'Diabetic glucose', 'wmsg': 'Pre-diabetic glucose'},
        'systolic_bp': {'danger': 140, 'warn': 130, 'msg': 'Hypertension Stage 2', 'wmsg': 'Elevated BP'},
        'ldl': {'danger': 160, 'warn': 100, 'msg': 'High LDL', 'wmsg': 'Borderline LDL'},
        'triglycerides': {'danger': 200, 'warn': 150, 'msg': 'High triglycerides', 'wmsg': 'Borderline TG'},
        'creatinine': {'danger': 1.5, 'warn': 1.2, 'msg': 'Elevated creatinine', 'wmsg': 'Borderline creatinine'},
    }

    for key, cfg in checks.items():
        val = trends.get(key, {}).get('latest', 0)
        if val >= cfg['danger']:
            risk_score += 25
            alerts.append(f"{cfg['msg']}: {val}")
        elif val >= cfg['warn']:
            risk_score += 10
            alerts.append(f"{cfg['wmsg']}: {val}")

    # HDL inverse
    hdl = trends.get('hdl', {}).get('latest', 99)
    if hdl < 40: risk_score += 20; alerts.append(f"Low HDL: {hdl}")

    # Vitamin D inverse
    vitd = trends.get('vitamin_d', {}).get('latest', 99)
    if vitd < 20: risk_score += 15; alerts.append(f"Vitamin D deficient: {vitd}")

    if risk_score >= 60: level = 'critical'
    elif risk_score >= 40: level = 'high'
    elif risk_score >= 15: level = 'moderate'
    else: level = 'low'

    rec = 'SKIP_REMAINING' if level == 'low' else 'CONTINUE'

    return {
        'agent': 'temporal_pattern_analyzer',
        'risk_level': level,
        'summary': f"Rule-based analysis: {len(alerts)} concerning findings. Risk score: {risk_score}.",
        'biomarker_trends': [],
        'critical_alerts': alerts,
        'time_to_threshold': [],
        'recommendation': rec,
        '_source': 'rule_based_fallback'
    }


def lambda_handler(event, context):
    try:
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event

        patient_id = body.get('patient_id')
        gold_data = body.get('gold_data')

        if not gold_data:
            try:
                key = f"medallion/gold/{patient_id}/summary.json"
                obj = s3.get_object(Bucket=BUCKET, Key=key)
                gold_data = json.loads(obj['Body'].read())
            except:
                return respond(404, {'error': f'No gold data for {patient_id}'})

        prompt = f"""Analyze this patient's biomarker data for temporal patterns.

PATIENT DATA:
{json.dumps(gold_data, indent=2)}

Analyze each biomarker's trend, rate of change, threshold proximity, and clinical significance.
Apply Indian population reference ranges. Be specific with numbers.
If the patient has only one data point per biomarker, analyze static values against thresholds.
Determine if deeper analysis (Agents 2-4) is needed or can be skipped."""

        try:
            result, model_used = call_bedrock_with_retry(prompt, SYSTEM_PROMPT)
            result['_model_used'] = model_used
            result['_source'] = 'bedrock_live'
            result['_analyzed_at'] = datetime.utcnow().isoformat()

            # Cache for future fallback
            cache_result(patient_id, 'temporal', result)
            result['_cached_at'] = datetime.utcnow().isoformat()

        except Exception as bedrock_err:
            print(f"All Bedrock models failed: {bedrock_err}")
            cached = get_cached_result(patient_id, 'temporal')
            if cached:
                result = cached
            else:
                result = rule_based_fallback(gold_data)

        # Save session
        save_session(patient_id, 'agent_1_temporal', result)

        return respond(200, result)

    except Exception as e:
        print(f"Agent 1 error: {e}")
        return respond(500, {'error': str(e), 'agent': 'temporal'})
