"""
BioClock — bioclock-etl Lambda (DynamoDB Risk Update)
After ETL completes, updates the patient's overall_risk in DynamoDB
so Dashboard KPIs show correct risk counts.
"""

import json
import boto3
import os
from datetime import datetime
import uuid
from decimal import Decimal

s3 = boto3.client('s3')
BUCKET = os.environ.get('BUCKET_NAME', 'bioclock-health-data')

# DynamoDB for updating risk
dynamodb = boto3.resource('dynamodb', region_name=os.environ.get('AWS_REGION', 'ap-south-1'))
TABLE_NAME = os.environ.get('DYNAMODB_TABLE', 'bioclock-patients')

REFERENCE_RANGES = {
    'hba1c': {'normal': (4.0, 5.7), 'warning': (5.7, 6.4), 'danger': (6.5, 15), 'unit': '%'},
    'fasting_glucose': {'normal': (70, 100), 'warning': (100, 126), 'danger': (126, 500), 'unit': 'mg/dL'},
    'systolic_bp': {'normal': (90, 120), 'warning': (120, 140), 'danger': (140, 220), 'unit': 'mmHg'},
    'diastolic_bp': {'normal': (60, 80), 'warning': (80, 90), 'danger': (90, 140), 'unit': 'mmHg'},
    'ldl': {'normal': (0, 100), 'warning': (100, 160), 'danger': (160, 400), 'unit': 'mg/dL'},
    'hdl': {'normal': (60, 120), 'warning': (40, 60), 'danger': (0, 40), 'unit': 'mg/dL', 'inverse': True},
    'triglycerides': {'normal': (0, 150), 'warning': (150, 200), 'danger': (200, 1000), 'unit': 'mg/dL'},
    'creatinine': {'normal': (0.6, 1.2), 'warning': (1.2, 2.0), 'danger': (2.0, 15), 'unit': 'mg/dL'},
    'tsh': {'normal': (0.4, 4.0), 'warning': (4.0, 10), 'danger': (10, 50), 'unit': 'mIU/L'},
    'vitamin_d': {'normal': (30, 100), 'warning': (20, 30), 'danger': (0, 20), 'unit': 'ng/mL', 'inverse': True},
    'uric_acid': {'normal': (2.4, 6.0), 'warning': (6.0, 7.0), 'danger': (7.0, 15), 'unit': 'mg/dL'},
    'hemoglobin': {'normal': (12, 17), 'warning': (10, 12), 'danger': (0, 10), 'unit': 'g/dL', 'inverse': True},
}

def respond(code, body):
    return {
        'statusCode': code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps(body)
    }

def classify_value(key, value):
    ref = REFERENCE_RANGES.get(key)
    if not ref: return 'unknown'
    if ref.get('inverse'):
        if value <= ref['danger'][1]: return 'danger'
        elif value <= ref['warning'][1]: return 'warning'
        return 'normal'
    else:
        if value >= ref['danger'][0]: return 'danger'
        elif value >= ref['warning'][0]: return 'warning'
        return 'normal'

def lambda_handler(event, context):
    if event.get('httpMethod') == 'OPTIONS':
        return respond(200, {'message': 'OK'})

    try:
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event

        patient_id = body.get('patient_id')
        if not patient_id:
            return respond(400, {'error': 'patient_id is required'})

        # Read latest bronze
        bronze_prefix = f"medallion/bronze/{patient_id}/"
        result = s3.list_objects_v2(Bucket=BUCKET, Prefix=bronze_prefix)
        contents = result.get('Contents', [])
        if not contents:
            return respond(404, {'error': f'No bronze data for {patient_id}'})

        latest = sorted(contents, key=lambda x: x['LastModified'], reverse=True)[0]
        bronze_obj = s3.get_object(Bucket=BUCKET, Key=latest['Key'])
        bronze_data = json.loads(bronze_obj['Body'].read())

        biomarkers = bronze_data.get('biomarkers', {})
        for key in REFERENCE_RANGES:
            if key in bronze_data and key not in biomarkers:
                try: biomarkers[key] = float(bronze_data[key])
                except: pass

        # Clean biomarkers
        cleaned = {}
        quality_flags = []
        risk_score = 0
        risk_flags = []
        disease_signals = []

        for key, value in biomarkers.items():
            try:
                val = float(value)
                ref = REFERENCE_RANGES.get(key)
                if ref:
                    status = classify_value(key, val)
                    cleaned[key] = {'value': val, 'unit': ref['unit'], 'status': status}
                    if status == 'danger':
                        risk_score += 20
                        risk_flags.append(f"{key}: {val} {ref['unit']} (CRITICAL)")
                    elif status == 'warning':
                        risk_score += 10
                        risk_flags.append(f"{key}: {val} {ref['unit']} (borderline)")
            except: pass

        # Disease signals
        hba1c = cleaned.get('hba1c', {}).get('value', 0)
        fg = cleaned.get('fasting_glucose', {}).get('value', 0)
        sbp = cleaned.get('systolic_bp', {}).get('value', 0)
        ldl = cleaned.get('ldl', {}).get('value', 0)
        hdl = cleaned.get('hdl', {}).get('value', 999)
        tg = cleaned.get('triglycerides', {}).get('value', 0)

        if hba1c >= 6.5 or fg >= 126: disease_signals.append('Diabetes_likely')
        elif hba1c >= 5.7 or fg >= 100: disease_signals.append('Pre-diabetes')
        if sbp >= 140: disease_signals.append('Hypertension')
        elif sbp >= 130: disease_signals.append('Pre-hypertension')
        if ldl >= 160 or (hdl < 40 and tg >= 200): disease_signals.append('Cardiovascular_risk')

        # Overall risk
        if risk_score >= 60: overall_risk = 'critical'
        elif risk_score >= 40: overall_risk = 'high'
        elif risk_score >= 20: overall_risk = 'moderate'
        else: overall_risk = 'low'

        # Save Silver
        ts = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        uid = uuid.uuid4().hex[:8]
        silver_data = {
            'patient_id': patient_id, 'biomarkers': cleaned,
            'quality_flags': quality_flags, 'cleaned_at': datetime.utcnow().isoformat(),
            'biomarker_count': len(cleaned)
        }
        silver_key = f"medallion/silver/{patient_id}/{ts}_{uid}.json"
        s3.put_object(Bucket=BUCKET, Key=silver_key, Body=json.dumps(silver_data, indent=2), ContentType='application/json')

        # Save Gold
        biomarker_trends = {}
        for key, data in cleaned.items():
            biomarker_trends[key] = {'latest': data['value'], 'unit': data['unit'], 'status': data['status'], 'trend': 'stable'}

        gold_data = {
            'patient_id': patient_id,
            'profile': {
                'name': bronze_data.get('name', ''), 'age': bronze_data.get('age', 0),
                'sex': bronze_data.get('sex', ''), 'city': bronze_data.get('city', ''),
                'bmi': bronze_data.get('bmi', 0), 'smoker': bronze_data.get('smoker', False),
                'family_history': bronze_data.get('family_history', False)
            },
            'biomarker_trends': biomarker_trends, 'risk_flags': risk_flags,
            'disease_signals': disease_signals, 'overall_risk': overall_risk,
            'risk_score': risk_score, 'biomarker_count': len(cleaned),
            'analyzed_at': datetime.utcnow().isoformat()
        }
        gold_key = f"medallion/gold/{patient_id}/summary.json"
        s3.put_object(Bucket=BUCKET, Key=gold_key, Body=json.dumps(gold_data, indent=2), ContentType='application/json')

        # ═══ UPDATE DYNAMODB WITH RISK LEVEL ═══
        try:
            table = dynamodb.Table(TABLE_NAME)
            table.update_item(
                Key={'patient_id': patient_id},
                UpdateExpression='SET overall_risk = :risk, risk_score = :score, disease_signals = :signals, biomarker_count = :count',
                ExpressionAttributeValues={
                    ':risk': overall_risk,
                    ':score': Decimal(str(risk_score)),
                    ':signals': disease_signals,
                    ':count': len(cleaned)
                }
            )
            print(f"✅ DynamoDB updated: {patient_id} → {overall_risk}")
        except Exception as dynamo_err:
            print(f"⚠️ DynamoDB update failed: {dynamo_err}")

        return respond(200, {
            'message': 'ETL pipeline completed',
            'patient_id': patient_id,
            'silver_key': silver_key, 'gold_key': gold_key,
            'biomarkers_processed': len(cleaned),
            'risk_flags': len(risk_flags),
            'disease_signals': disease_signals,
            'overall_risk': overall_risk
        })

    except Exception as e:
        print(f"ETL error: {e}")
        return respond(500, {'error': str(e)})
