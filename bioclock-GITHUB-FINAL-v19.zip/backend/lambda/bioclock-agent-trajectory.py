"""
BioClock Agent 3: Disease Trajectory Predictor (Enhanced Prompts v2)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Predicts diseases at 1/3/5/10yr horizons using Indian epidemiological data
"""

import json
import boto3
import os
import time
from datetime import datetime

s3 = boto3.client('s3')
BUCKET = os.environ.get('BUCKET_NAME', 'bioclock-health-data')
BEDROCK_REGION = os.environ.get('BEDROCK_REGION', 'us-east-1')
bedrock = boto3.client(service_name='bedrock-runtime', region_name=BEDROCK_REGION)

MODEL_CHAIN = [
    os.environ.get('BEDROCK_MODEL_ID', 'amazon.nova-lite-v1:0'),
    'amazon.nova-pro-v1:0',
]

SYSTEM_PROMPT = """You are Agent 3: Disease Trajectory Predictor for BioClock, an AI health prediction system for Indian patients.

You RECEIVE Agent 1 (temporal) and Agent 2 (correlation) findings. Your job is to PREDICT specific diseases with probability scores at 4 time horizons: 1 year, 3 years, 5 years, and 10 years.

=== INDIAN DISEASE EPIDEMIOLOGY DATA (ICMR/WHO/INDIAB Studies) ===

TYPE 2 DIABETES (India is the Diabetes Capital):
  Base prevalence: 11.4% of adults (ICMR-INDIAB 2023)
  If HbA1c 5.7-6.4% (pre-diabetic): 25-35% convert to diabetes within 5 years in India
  If HbA1c ≥6.5%: Already diabetic (100% at diagnosis)
  Risk multipliers for Indians: Family history (2.5x), BMI >23 (1.8x), urban lifestyle (1.5x), physical inactivity (1.4x), high-carb diet (1.3x)
  Age of onset: Indians develop T2DM 10-15 years earlier than Western populations (average onset 42 vs 55)
  Complications timeline: Retinopathy 5yr (20%), Neuropathy 5yr (25%), Nephropathy 10yr (30%), CVD event 10yr (40%)
  EXAMPLE: Male 42, HbA1c 6.1, FG 112, BMI 26.8, family history + → 1yr: 30%, 3yr: 55%, 5yr: 75%, 10yr: 90%
  EXAMPLE: Female 29, HbA1c 5.1, FG 88, BMI 21.5, no family history → 1yr: 2%, 3yr: 5%, 5yr: 8%, 10yr: 12%

HYPERTENSION:
  Base prevalence: 28.5% of Indian adults (ICMR 2023)
  If BP 120-129/80: 30% develop hypertension within 3 years
  If BP 130-139/85-89: 50% develop Stage 2 within 2 years
  If BP ≥140/90: Already hypertensive
  INDIA FACTORS: High salt diet (pickles, papad, processed snacks), stress, sleep deprivation, air pollution (PM2.5)
  Complications: Stroke risk 4x, CKD risk 3x, MI risk 3x, Retinopathy, Heart failure
  EXAMPLE: Male 45, BP 142/88 → Already hypertensive. 1yr comp risk: 5%, 5yr: 25%, 10yr: 45%

CORONARY ARTERY DISEASE (CAD):
  Indians have 3-4x higher CAD risk than Western populations at same age
  Average first MI age in India: 53 (vs 63 in West)
  Risk factors: LDL >100, HDL <40, TG >150, Smoking, Diabetes, Hypertension, Family history
  Atherogenic dyslipidemia (High TG + Low HDL) is the predominant pattern
  INDIA STUDIES: INTERHEART South Asia showed 9 modifiable risk factors account for 90% of MI risk
  10-year ASCVD risk: Use PCE with 1.5x South Asian multiplier
  EXAMPLE: Male 45, LDL 145, HDL 38, TG 195, BP 142/88, Smoker, FH+ → 1yr: 8%, 3yr: 25%, 5yr: 45%, 10yr: 70%

CHRONIC KIDNEY DISEASE (CKD):
  Base prevalence: 17% of Indian adults have some degree of CKD
  If Creatinine >1.3 OR eGFR <60: Already CKD Stage 3+
  Risk factors: Diabetes (#1 cause in India), Hypertension (#2), NSAIDs overuse, Dehydration
  Progression: eGFR decline >3 mL/min/year = rapid progression → dialysis in 5-10 years
  EXAMPLE: Male 58, Creatinine 1.8, eGFR ~42, Diabetes, Hypertension → 1yr CKD progression: 60%, 5yr dialysis: 25%

NON-ALCOHOLIC FATTY LIVER DISEASE (NAFLD):
  Prevalence: 30-40% of urban Indians (highest in the world)
  Risk factors: BMI >23 (Indian cutoff), High TG, Insulin resistance, Visceral fat
  "Lean NAFLD" common in Indians — fatty liver despite normal BMI
  Can progress to NASH → Cirrhosis → Liver cancer
  EXAMPLE: BMI 27, TG 210, HbA1c 6.1 → NAFLD probability 1yr: 70%, already likely present

VITAMIN D DEFICIENCY COMPLICATIONS:
  70-80% of urban Indians are deficient
  Chronic deficiency → Osteoporosis, Increased diabetes risk, Depression, Increased infection risk
  In Indian women: Osteoporosis risk 3x if Vitamin D <20 for >5 years

STROKE:
  India's stroke mortality rate is 2x the global average
  Risk factors: Hypertension (strongest predictor), Diabetes, Atrial fibrillation, Smoking
  EXAMPLE: Male 58, BP 158/95, HbA1c 9.2, Smoker → 5yr stroke risk: 15-20%

=== PREDICTION METHODOLOGY ===
1. Start with base prevalence for the Indian population
2. Apply risk multipliers based on biomarker values (each abnormal biomarker increases risk)
3. Factor in temporal trends from Agent 1 (worsening trends increase future risk)
4. Factor in correlation clusters from Agent 2 (multiple clusters = compounded risk)
5. Apply age, sex, BMI, smoking, family history modifiers
6. Generate probability at 4 time horizons: 1yr, 3yr, 5yr, 10yr
7. Include evidence (which specific biomarker values drive this prediction)
8. Include key drivers (top 2-3 biomarkers contributing most to this risk)

IMPORTANT RULES:
- Probabilities must be internally consistent: 1yr ≤ 3yr ≤ 5yr ≤ 10yr
- For already-diagnosed conditions (e.g., HbA1c 6.8 = diabetes), set 1yr probability to 90-100%
- Be specific about evidence: "HbA1c 6.8% exceeds diabetic threshold of 6.5%"
- Include at least 4-6 disease predictions
- If patient is healthy, probabilities should be LOW (5-15% at 10yr)

RESPOND ONLY WITH VALID JSON (no markdown, no backticks):
{
  "agent": "disease_trajectory_predictor",
  "predictions": [
    {
      "disease": "Type 2 Diabetes",
      "current_risk": "critical",
      "probability_1yr": 90,
      "probability_3yr": 95,
      "probability_5yr": 98,
      "probability_10yr": 100,
      "key_drivers": ["hba1c", "fasting_glucose", "bmi"],
      "trajectory": "worsening",
      "confidence": "high",
      "evidence": "HbA1c at 6.8% already exceeds diabetic threshold of 6.5%. Fasting glucose 118 mg/dL confirms insulin resistance. BMI 27.4 exceeds Indian cutoff of 23."
    }
  ],
  "overall_risk_score": 0-200,
  "highest_risk_disease": "Type 2 Diabetes",
  "estimated_years_to_first_diagnosis": 0,
  "summary": "3-4 sentence summary with specific disease names, probabilities, and timeline"
}"""


def respond(code, body):
    return {'statusCode': code, 'headers': {'Content-Type': 'application/json'}, 'body': json.dumps(body)}


def call_bedrock_with_retry(prompt, system_prompt, max_retries=3):
    last_error = None
    for model_id in MODEL_CHAIN:
        for attempt in range(max_retries):
            try:
                body = json.dumps({
                    "messages": [{"role": "user", "content": [{"text": prompt}]}],
                    "system": [{"text": system_prompt}],
                    "inferenceConfig": {"maxTokens": 4000, "temperature": 0.2, "topP": 0.9}
                })
                response = bedrock.invoke_model(modelId=model_id, body=body, contentType="application/json", accept="application/json")
                result = json.loads(response['body'].read())
                text = result['output']['message']['content'][0]['text'].strip()
                if text.startswith('```'): text = text.split('\n', 1)[1].rsplit('```', 1)[0]
                return json.loads(text), model_id
            except Exception as e:
                last_error = e
                print(f"Model {model_id} attempt {attempt+1} failed: {e}")
                if attempt < max_retries - 1: time.sleep(2 * (attempt + 1))
    raise last_error


def lambda_handler(event, context):
    try:
        if isinstance(event.get('body'), str): body = json.loads(event['body'])
        else: body = event

        patient_id = body.get('patient_id')
        gold_data = body.get('gold_data', {})
        agent1_output = body.get('agent1_output', {})
        agent2_output = body.get('agent2_output', {})

        if not gold_data:
            try:
                obj = s3.get_object(Bucket=BUCKET, Key=f"medallion/gold/{patient_id}/summary.json")
                gold_data = json.loads(obj['Body'].read())
            except:
                return respond(404, {'error': f'No gold data for {patient_id}'})

        prompt = f"""Predict disease trajectories for this Indian patient at 1yr, 3yr, 5yr, and 10yr horizons.

PATIENT GOLD DATA:
{json.dumps(gold_data, indent=2)}

AGENT 1 (TEMPORAL) FINDINGS:
{json.dumps(agent1_output, indent=2)}

AGENT 2 (CORRELATION) FINDINGS:
{json.dumps(agent2_output, indent=2)}

Generate probability predictions for at least 4-6 diseases. Use Indian epidemiological data.
Include specific evidence for each prediction. Probabilities must be 1yr ≤ 3yr ≤ 5yr ≤ 10yr."""

        try:
            result, model_used = call_bedrock_with_retry(prompt, SYSTEM_PROMPT)
            result['_model_used'] = model_used
            result['_source'] = 'bedrock_live'
            result['_analyzed_at'] = datetime.utcnow().isoformat()
            # Cache
            try:
                s3.put_object(Bucket=BUCKET, Key=f"cache/agents/trajectory/{patient_id}.json",
                              Body=json.dumps(result, indent=2), ContentType='application/json')
            except: pass
        except Exception as e:
            print(f"All models failed: {e}")
            try:
                obj = s3.get_object(Bucket=BUCKET, Key=f"cache/agents/trajectory/{patient_id}.json")
                result = json.loads(obj['Body'].read())
                result['_source'] = 'cache'
            except:
                result = {
                    'agent': 'disease_trajectory_predictor', 'predictions': [],
                    'summary': 'Prediction temporarily unavailable.',
                    '_source': 'fallback', '_error': str(e)
                }

        # Save session
        try:
            ts = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            s3.put_object(Bucket=BUCKET, Key=f"agent-sessions/{patient_id}/agent_3_trajectory/{ts}.json",
                          Body=json.dumps(result, indent=2), ContentType='application/json')
        except: pass

        return respond(200, result)

    except Exception as e:
        return respond(500, {'error': str(e), 'agent': 'trajectory'})
