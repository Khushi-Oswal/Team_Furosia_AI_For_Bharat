"""
BioClock — bioclock-translate Lambda
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Uses Amazon Translate to translate health reports
to 8 Indian languages.

Supported languages:
  hi = Hindi, ta = Tamil, te = Telugu, mr = Marathi,
  bn = Bengali, kn = Kannada, gu = Gujarati, pa = Punjabi

API: POST /api/translate
Body: { "text": "...", "target_language": "hi" }
"""

import json
import boto3
import os

# Initialize Amazon Translate client
translate_client = boto3.client(
    service_name='translate',
    region_name=os.environ.get('AWS_REGION', 'ap-south-1')
)

# Supported language codes (Amazon Translate codes)
SUPPORTED_LANGUAGES = {
    'hi': 'Hindi',
    'ta': 'Tamil',
    'te': 'Telugu',
    'mr': 'Marathi',
    'bn': 'Bengali',
    'kn': 'Kannada',
    'gu': 'Gujarati',
    'pa': 'Punjabi',
    'ml': 'Malayalam',
    'or': 'Odia',
    'ur': 'Urdu',
}

# Maximum characters per request (Amazon Translate limit is 10,000 bytes)
MAX_TEXT_LENGTH = 5000


def respond(status_code, body):
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps(body, ensure_ascii=False)  # ensure_ascii=False to preserve Hindi/Tamil chars
    }


def translate_text_chunks(text, target_language):
    """
    Translate text, splitting into chunks if too long.
    Amazon Translate has a 10,000 byte limit per request.
    """
    # If text is short enough, translate directly
    if len(text.encode('utf-8')) <= 9500:
        result = translate_client.translate_text(
            Text=text,
            SourceLanguageCode='en',
            TargetLanguageCode=target_language,
            Settings={
                'Formality': 'FORMAL',  # Medical reports should be formal
                'Brevity': 'OFF'
            }
        )
        return result['TranslatedText']

    # Split into paragraphs and translate each
    paragraphs = text.split('\n')
    translated_parts = []
    current_chunk = ''

    for para in paragraphs:
        # If adding this paragraph would exceed limit, translate current chunk first
        if len((current_chunk + '\n' + para).encode('utf-8')) > 9500:
            if current_chunk:
                result = translate_client.translate_text(
                    Text=current_chunk,
                    SourceLanguageCode='en',
                    TargetLanguageCode=target_language
                )
                translated_parts.append(result['TranslatedText'])
            current_chunk = para
        else:
            current_chunk = current_chunk + '\n' + para if current_chunk else para

    # Translate remaining chunk
    if current_chunk:
        result = translate_client.translate_text(
            Text=current_chunk,
            SourceLanguageCode='en',
            TargetLanguageCode=target_language
        )
        translated_parts.append(result['TranslatedText'])

    return '\n'.join(translated_parts)


def lambda_handler(event, context):
    # Handle CORS preflight
    if event.get('httpMethod') == 'OPTIONS':
        return respond(200, {'message': 'OK'})

    try:
        # Parse request body
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event

        text = body.get('text', '')
        target_language = body.get('target_language', '')

        # Validation
        if not text:
            return respond(400, {'error': 'text is required'})

        if not target_language:
            return respond(400, {'error': 'target_language is required (e.g., hi, ta, te, mr, bn)'})

        if target_language not in SUPPORTED_LANGUAGES:
            return respond(400, {
                'error': f'Unsupported language: {target_language}',
                'supported': SUPPORTED_LANGUAGES
            })

        # Truncate if too long
        if len(text) > MAX_TEXT_LENGTH:
            text = text[:MAX_TEXT_LENGTH] + '...'
            print(f"⚠️ Text truncated to {MAX_TEXT_LENGTH} chars")

        print(f"🌐 Translating {len(text)} chars to {SUPPORTED_LANGUAGES[target_language]} ({target_language})")

        # ═══ CALL AMAZON TRANSLATE ═══
        try:
            translated_text = translate_text_chunks(text, target_language)

            print(f"✅ Translation successful: {len(translated_text)} chars")

            return respond(200, {
                'translated_text': translated_text,
                'source_language': 'en',
                'target_language': target_language,
                'target_language_name': SUPPORTED_LANGUAGES[target_language],
                'original_length': len(text),
                'translated_length': len(translated_text),
                'service': 'Amazon Translate'
            })

        except translate_client.exceptions.UnsupportedLanguagePairException:
            return respond(400, {
                'error': f'Language pair en → {target_language} is not supported by Amazon Translate',
                'target_language': target_language
            })

        except translate_client.exceptions.TextSizeLimitExceededException:
            # Try with truncated text
            short_text = text[:2000]
            result = translate_client.translate_text(
                Text=short_text,
                SourceLanguageCode='en',
                TargetLanguageCode=target_language
            )
            return respond(200, {
                'translated_text': result['TranslatedText'],
                'source_language': 'en',
                'target_language': target_language,
                'target_language_name': SUPPORTED_LANGUAGES[target_language],
                'truncated': True,
                'service': 'Amazon Translate'
            })

        except Exception as translate_error:
            print(f"❌ Amazon Translate failed: {translate_error}")

            # ═══ FALLBACK: Use Bedrock for translation ═══
            try:
                print("🔄 Falling back to Bedrock for translation...")
                bedrock = boto3.client(
                    service_name='bedrock-runtime',
                    region_name=os.environ.get('BEDROCK_REGION', 'us-east-1')
                )

                prompt = f"""Translate the following English medical report to {SUPPORTED_LANGUAGES[target_language]}.
Keep medical terminology accurate. Use formal language appropriate for health reports.

Text to translate:
{text[:3000]}

Provide ONLY the translated text, nothing else."""

                bedrock_body = json.dumps({
                    "messages": [{"role": "user", "content": [{"text": prompt}]}],
                    "system": [{"text": f"You are a medical translator. Translate accurately to {SUPPORTED_LANGUAGES[target_language]}. Output ONLY the translation."}],
                    "inferenceConfig": {"maxTokens": 4096, "temperature": 0.1}
                })

                model_id = os.environ.get('BEDROCK_MODEL_ID', 'amazon.nova-lite-v1:0')
                response = bedrock.invoke_model(
                    modelId=model_id,
                    contentType='application/json',
                    accept='application/json',
                    body=bedrock_body
                )

                result = json.loads(response['body'].read())
                fallback_text = result['output']['message']['content'][0]['text']

                return respond(200, {
                    'translated_text': fallback_text,
                    'source_language': 'en',
                    'target_language': target_language,
                    'target_language_name': SUPPORTED_LANGUAGES[target_language],
                    'service': 'Bedrock Fallback',
                    'fallback': True
                })

            except Exception as bedrock_error:
                print(f"❌ Bedrock fallback also failed: {bedrock_error}")
                return respond(500, {
                    'error': 'Translation failed',
                    'details': str(translate_error),
                    'fallback_error': str(bedrock_error)
                })

    except Exception as e:
        print(f"❌ Handler error: {e}")
        return respond(500, {'error': str(e)})
