"""
BioClock Orchestrator: bioclock-analyze
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Calls Agent 1 → Supervisor Decision → Agent 2 → 3 → 4
With retry on each agent + graceful degradation
"""

import json
import boto3
import os
import time
from datetime import datetime

s3 = boto3.client('s3')
lambda_client = boto3.client('lambda', region_name=os.environ.get('LAMBDA_REGION', 'ap-south-1'))
BUCKET = os.environ.get('BUCKET_NAME', 'bioclock-health-data')

# Agent Lambda function names
AGENT_FUNCTIONS = {
    'agent1': os.environ.get('AGENT_1_FUNCTION', 'bioclock-agent-temporal'),
    'agent2': os.environ.get('AGENT_2_FUNCTION', 'bioclock-agent-correlator'),
    'agent3': os.environ.get('AGENT_3_FUNCTION', 'bioclock-agent-trajectory'),
    'agent4': os.environ.get('AGENT_4_FUNCTION', 'bioclock-agent-intervention'),
}


def respond(code, body):
    return {'statusCode': code, 'headers': {
        'Content-Type': 'application/json', 
        
        }, 'body': json.dumps(body)}


def invoke_agent(agent_name, payload, max_retries=2):
    """Invoke an agent Lambda with retry"""
    func_name = AGENT_FUNCTIONS.get(agent_name)
    if not func_name:
        raise Exception(f"Unknown agent: {agent_name}")

    last_error = None
    for attempt in range(max_retries):
        try:
            response = lambda_client.invoke(
                FunctionName=func_name,
                InvocationType='RequestResponse',
                Payload=json.dumps(payload)
            )
            result_payload = json.loads(response['Payload'].read())

            # Parse the Lambda response
            if isinstance(result_payload.get('body'), str):
                return json.loads(result_payload['body'])
            return result_payload

        except Exception as e:
            print(f"⚠️ Agent {agent_name} attempt {attempt+1} failed: {e}")
            last_error = e
            if attempt < max_retries - 1:
                time.sleep(2)

    # Return error object instead of crashing
    return {
        'agent': agent_name,
        '_error': str(last_error),
        '_source': 'agent_invoke_failed',
        'summary': f'Agent {agent_name} temporarily unavailable'
    }


def lambda_handler(event, context):
    start_time = time.time()

    try:
        # Parse input
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event

        patient_id = body.get('patient_id')
        if not patient_id:
            return respond(400, {'error': 'patient_id is required'})

        print(f"🚀 Starting analysis for patient: {patient_id}")

        # ═══ LOAD GOLD DATA FROM S3 ═══
        gold_data = None
        try:
            gold_key = f"medallion/gold/{patient_id}/summary.json"
            resp = s3.get_object(Bucket=BUCKET, Key=gold_key)
            gold_data = json.loads(resp['Body'].read())
            print(f"📂 Loaded gold data from {gold_key}")
        except Exception as e:
            # Try alternate path
            try:
                gold_key = f"gold/{patient_id}/summary.json"
                resp = s3.get_object(Bucket=BUCKET, Key=gold_key)
                gold_data = json.loads(resp['Body'].read())
                print(f"📂 Loaded gold data from {gold_key}")
            except:
                return respond(404, {'error': f'No gold data found for patient {patient_id}'})

        # Generate session ID
        session_id = f"session_{patient_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"

        # ═══ AGENT 1: TEMPORAL PATTERN ANALYSIS ═══
        print("🔵 Running Agent 1: Temporal Pattern Analysis...")
        agent1_result = invoke_agent('agent1', {
            'patient_id': patient_id,
            'gold_data': gold_data
        })
        print(f"   Agent 1 source: {agent1_result.get('_source', 'unknown')}")

        # ═══ SUPERVISOR DECISION ═══
        supervisor_decision = 'CONTINUE'
        supervisor_reason = ''

        agent1_recommendation = agent1_result.get('recommendation', 'CONTINUE')
        agent1_risk = agent1_result.get('risk_level', 'unknown')

        if agent1_recommendation == 'SKIP_REMAINING' and agent1_risk == 'low':
            supervisor_decision = 'SKIP'
            supervisor_reason = f"Agent 1 found low risk with stable biomarkers. Skipping deeper analysis to save cost."
            print(f"🧠 Supervisor: SKIP (healthy patient)")
        else:
            supervisor_reason = f"Agent 1 found {agent1_risk} risk. Continuing full 4-agent chain for comprehensive analysis."
            print(f"🧠 Supervisor: CONTINUE (risk={agent1_risk})")

        agent2_result = {}
        agent3_result = {}
        agent4_result = {}

        if supervisor_decision == 'CONTINUE':
            # ═══ AGENT 2: BIOMARKER CORRELATOR ═══
            print("🟣 Running Agent 2: Biomarker Correlator...")
            agent2_result = invoke_agent('agent2', {
                'patient_id': patient_id,
                'gold_data': gold_data,
                'agent1_output': agent1_result
            })

            # ═══ AGENT 3: DISEASE TRAJECTORY ═══
            print("🔴 Running Agent 3: Disease Trajectory...")
            agent3_result = invoke_agent('agent3', {
                'patient_id': patient_id,
                'gold_data': gold_data,
                'agent1_output': agent1_result,
                'agent2_output': agent2_result
            })

            # ═══ AGENT 4: INTERVENTION PLANNER ═══
            print("🟢 Running Agent 4: Intervention Planner...")
            agent4_result = invoke_agent('agent4', {
                'patient_id': patient_id,
                'gold_data': gold_data,
                'agent1_output': agent1_result,
                'agent2_output': agent2_result,
                'agent3_output': agent3_result
            })

        elapsed = round(time.time() - start_time, 2)
        agents_run = 1 if supervisor_decision == 'SKIP' else 4

        # ═══ COMPILE FULL RESULT ═══
        full_result = {
            'session_id': session_id,
            'patient_id': patient_id,
            'timestamp': datetime.utcnow().isoformat(),
            'elapsed_seconds': elapsed,
            'agents_run': agents_run,
            'supervisor': {
                'decision': supervisor_decision,
                'reason': supervisor_reason,
                'agent1_risk': agent1_risk,
                'agent1_recommendation': agent1_recommendation
            },
            'reasoning': {
                'agent1': agent1_result.get('summary', str(agent1_result)),
                'agent2': agent2_result.get('summary', ''),
                'agent3': agent3_result.get('summary', ''),
                'agent4': agent4_result.get('summary', ''),
                'supervisor': supervisor_reason,
                'supervisor_decision': supervisor_decision
            },
            'agent_details': {
                'agent1_temporal': agent1_result,
                'agent2_correlator': agent2_result,
                'agent3_trajectory': agent3_result,
                'agent4_intervention': agent4_result
            },
            'predictions': agent3_result.get('predictions', []),
            'overall_risk': agent1_result.get('risk_level', 'unknown'),
            'fallback_info': {
                'agent1_source': agent1_result.get('_source', 'unknown'),
                'agent2_source': agent2_result.get('_source', 'unknown') if agent2_result else 'skipped',
                'agent3_source': agent3_result.get('_source', 'unknown') if agent3_result else 'skipped',
                'agent4_source': agent4_result.get('_source', 'unknown') if agent4_result else 'skipped',
            }
        }

        # ═══ SAVE TO S3 ═══
        # Save full session
        session_key = f"agent-sessions/{patient_id}/{session_id}.json"
        s3.put_object(Bucket=BUCKET, Key=session_key,
                      Body=json.dumps(full_result, indent=2), ContentType='application/json')

        # Save predictions
        pred_key = f"predictions/{patient_id}/latest.json"
        s3.put_object(Bucket=BUCKET, Key=pred_key,
                      Body=json.dumps(full_result, indent=2), ContentType='application/json')

        # Save reasoning
        reasoning_key = f"reasoning/{session_id}.json"
        s3.put_object(Bucket=BUCKET, Key=reasoning_key,
                      Body=json.dumps(full_result['reasoning'], indent=2), ContentType='application/json')

        print(f"✅ Analysis complete: {agents_run} agents, {elapsed}s, risk={full_result['overall_risk']}")
        return respond(200, full_result)

    except Exception as e:
        print(f"❌ Orchestrator error: {e}")
        return respond(500, {'error': str(e), 'patient_id': body.get('patient_id', 'unknown')})
