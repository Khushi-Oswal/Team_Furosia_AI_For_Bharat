"""
BioClock — bioclock-ingest Lambda (DynamoDB + User Filtering)
Saves user_id (Cognito sub) with each patient for per-user filtering.
"""

import json
import boto3
import os
import uuid
from datetime import datetime
from decimal import Decimal

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb', region_name=os.environ.get('AWS_REGION', 'ap-south-1'))

BUCKET = os.environ.get('BUCKET_NAME', 'bioclock-health-data')
TABLE_NAME = os.environ.get('DYNAMODB_TABLE', 'bioclock-patients')
table = dynamodb.Table(TABLE_NAME)


def to_decimal(val):
    if val is None: return None
    try: return Decimal(str(val))
    except: return val


def respond(code, body):
    return {
        'statusCode': code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps(body)
    }


def lambda_handler(event, context):
    if event.get('httpMethod') == 'OPTIONS':
        return respond(200, {'message': 'OK'})

    try:
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event

        patient_id = body.get('patient_id') or ('BIO' + uuid.uuid4().hex[:8].upper())
        name = body.get('name', 'Unknown')
        age = body.get('age', 0)
        sex = body.get('sex', 'Unknown')
        city = body.get('city', 'Unknown')
        bmi = body.get('bmi', 0)
        smoker = body.get('smoker', False)
        family_history = body.get('family_history', False)
        source = body.get('source', 'manual_entry')
        user_id = body.get('user_id', 'anonymous')
        user_email = body.get('user_email', '')

        # Extract biomarkers
        biomarkers = {}
        for key in ['hba1c', 'fasting_glucose', 'systolic_bp', 'diastolic_bp',
                     'ldl', 'hdl', 'triglycerides', 'creatinine', 'tsh',
                     'vitamin_d', 'uric_acid', 'hemoglobin']:
            val = body.get(key) or body.get('biomarkers', {}).get(key)
            if val is not None:
                try: biomarkers[key] = float(val)
                except: pass

        if not biomarkers:
            return respond(400, {'error': 'No biomarker data provided'})

        now = datetime.utcnow().isoformat()
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        uid = uuid.uuid4().hex[:8]

        # Save to DynamoDB with user_id
        try:
            existing = table.get_item(Key={'patient_id': patient_id}).get('Item')
            record_count = int(existing.get('record_count', 0)) + 1 if existing else 1
            created_at = existing.get('created_at', now) if existing else now

            dynamo_item = {
                'patient_id': patient_id,
                'user_id': user_id,
                'user_email': user_email,
                'name': name,
                'age': int(age) if age else 0,
                'sex': sex,
                'city': city,
                'bmi': to_decimal(bmi),
                'smoker': smoker,
                'family_history': family_history,
                'overall_risk': 'pending',
                'biomarker_count': len(biomarkers),
                'record_count': record_count,
                'source': source,
                'created_at': created_at,
                'updated_at': now,
            }
            for k, v in biomarkers.items():
                dynamo_item[f'bio_{k}'] = to_decimal(v)

            table.put_item(Item=dynamo_item)
        except Exception as e:
            print(f"DynamoDB error: {e}")

        # Save to S3 Bronze
        record = {
            'patient_id': patient_id, 'user_id': user_id,
            'name': name, 'age': int(age) if age else 0, 'sex': sex,
            'city': city, 'bmi': float(bmi) if bmi else 0,
            'smoker': smoker, 'family_history': family_history,
            'biomarkers': biomarkers, 'ingested_at': now, 'source': source
        }
        bronze_key = f"medallion/bronze/{patient_id}/{timestamp}_{uid}.json"
        s3.put_object(Bucket=BUCKET, Key=bronze_key,
                      Body=json.dumps(record, indent=2), ContentType='application/json')

        # Save user profile
        profile = {
            'patient_id': patient_id, 'user_id': user_id,
            'name': name, 'age': int(age) if age else 0, 'sex': sex,
            'city': city, 'bmi': float(bmi) if bmi else 0,
            'updated_at': now, 'created_at': now
        }
        s3.put_object(Bucket=BUCKET, Key=f"users/{patient_id}/profile.json",
                      Body=json.dumps(profile, indent=2), ContentType='application/json')

        return respond(200, {
            'message': 'Patient data ingested successfully',
            'patient_id': patient_id,
            'bronze_key': bronze_key,
            'biomarkers_count': len(biomarkers),
            'source': source
        })

    except Exception as e:
        return respond(500, {'error': str(e)})
