"""
BioClock — bioclock-predict Lambda (DynamoDB Cache Version)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Reads predictions from DynamoDB (fast) with S3 fallback.
Also updates DynamoDB after new analysis.

DynamoDB Table: bioclock-predictions (Partition Key: patient_id)
"""

import json
import boto3
import os
from decimal import Decimal

dynamodb = boto3.resource('dynamodb', region_name=os.environ.get('AWS_REGION', 'ap-south-1'))
s3 = boto3.client('s3')
BUCKET = os.environ.get('BUCKET_NAME', 'bioclock-health-data')
PRED_TABLE = os.environ.get('PREDICTIONS_TABLE', 'bioclock-predictions')
pred_table = dynamodb.Table(PRED_TABLE)


class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super().default(obj)


def respond(code, body):
    return {
        'statusCode': code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps(body, cls=DecimalEncoder)
    }


def lambda_handler(event, context):
    if event.get('httpMethod') == 'OPTIONS':
        return respond(200, {'message': 'OK'})

    try:
        path_params = event.get('pathParameters', {}) or {}
        patient_id = path_params.get('userId', '')

        if not patient_id:
            return respond(400, {'error': 'userId is required'})

        # ═══ TRY DYNAMODB FIRST (fast — <10ms) ═══
        try:
            result = pred_table.get_item(Key={'patient_id': patient_id})
            if 'Item' in result:
                item = result['Item']
                print(f"✅ DynamoDB cache hit for {patient_id}")
                return respond(200, item)
        except Exception as dynamo_err:
            print(f"⚠️ DynamoDB lookup failed: {dynamo_err}")

        # ═══ FALLBACK TO S3 ═══
        try:
            obj = s3.get_object(Bucket=BUCKET, Key=f"predictions/{patient_id}/latest.json")
            predictions = json.loads(obj['Body'].read())
            print(f"📦 S3 hit for {patient_id}")
            return respond(200, predictions)
        except:
            pass

        return respond(404, {
            'error': f'No predictions found for {patient_id}',
            'patient_id': patient_id,
            'hint': 'Run AI Analysis first to generate predictions'
        })

    except Exception as e:
        return respond(500, {'error': str(e)})
