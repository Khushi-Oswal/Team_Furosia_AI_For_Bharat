"""
BioClock — bioclock-patients Lambda (User-Filtered)
Only returns patients belonging to the logged-in user.
"""

import json
import boto3
import os
from decimal import Decimal

dynamodb = boto3.resource('dynamodb', region_name=os.environ.get('AWS_REGION', 'ap-south-1'))
TABLE_NAME = os.environ.get('DYNAMODB_TABLE', 'bioclock-patients')
table = dynamodb.Table(TABLE_NAME)


class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal): return float(obj)
        return super().default(obj)


def respond(code, body):
    return {
        'statusCode': code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps(body, cls=DecimalEncoder)
    }


def lambda_handler(event, context):
    if event.get('httpMethod') == 'OPTIONS':
        return respond(200, {'message': 'OK'})

    try:
        # Get user_id from query parameter
        params = event.get('queryStringParameters') or {}
        user_id = params.get('user_id', '')

        # Scan DynamoDB
        result = table.scan()
        all_patients = result.get('Items', [])

        while 'LastEvaluatedKey' in result:
            result = table.scan(ExclusiveStartKey=result['LastEvaluatedKey'])
            all_patients.extend(result.get('Items', []))

        # Filter by user_id if provided
        if user_id:
            patients = [p for p in all_patients if p.get('user_id') == user_id]
        else:
            patients = all_patients

        # Sort by created_at descending
        patients.sort(key=lambda p: p.get('created_at', ''), reverse=True)

        return respond(200, {
            'patients': patients,
            'total': len(patients),
            'filtered_by': user_id if user_id else 'none',
            'source': 'dynamodb'
        })

    except Exception as e:
        print(f"Error: {e}")
        # Fallback to S3
        try:
            s3 = boto3.client('s3')
            BUCKET = os.environ.get('BUCKET_NAME', 'bioclock-health-data')
            patients = []
            result = s3.list_objects_v2(Bucket=BUCKET, Prefix='users/', Delimiter='/')
            for prefix in result.get('CommonPrefixes', []):
                pid = prefix['Prefix'].replace('users/', '').rstrip('/')
                try:
                    obj = s3.get_object(Bucket=BUCKET, Key=f"users/{pid}/profile.json")
                    profile = json.loads(obj['Body'].read())
                    if user_id and profile.get('user_id') != user_id:
                        continue
                    patients.append(profile)
                except: pass
            return respond(200, {'patients': patients, 'total': len(patients), 'source': 's3_fallback'})
        except Exception as s3_err:
            return respond(500, {'error': str(e)})
