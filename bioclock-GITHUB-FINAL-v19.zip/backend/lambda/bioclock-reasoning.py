import json
import boto3
import os

s3 = boto3.client('s3')
BUCKET = os.environ.get('BUCKET_NAME', 'bioclock-health-data')

def respond(code, body):
    return {
        'statusCode': code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        },
        'body': json.dumps(body)
    }

def lambda_handler(event, context):
    if event.get('httpMethod') == 'OPTIONS':
        return respond(200, {'message': 'OK'})

    try:
        path_params = event.get('pathParameters', {}) or {}
        session_id = path_params.get('sessionId', '')
        
        if not session_id:
            return respond(400, {'error': 'sessionId is required in path'})
        
        # Try reasoning path
        try:
            obj = s3.get_object(Bucket=BUCKET, Key=f"reasoning/{session_id}.json")
            reasoning = json.loads(obj['Body'].read())
            return respond(200, reasoning)
        except:
            pass
        
        # Try agent-sessions path
        try:
            result = s3.list_objects_v2(Bucket=BUCKET, Prefix=f"agent-sessions/", MaxKeys=50)
            for content in result.get('Contents', []):
                if session_id in content['Key']:
                    obj = s3.get_object(Bucket=BUCKET, Key=content['Key'])
                    data = json.loads(obj['Body'].read())
                    return respond(200, data.get('reasoning', data))
        except:
            pass
        
        return respond(404, {
            'error': f'No reasoning found for session {session_id}',
            'session_id': session_id
        })
        
    except Exception as e:
        print(f"Error: {e}")
        return respond(500, {'error': str(e)})
