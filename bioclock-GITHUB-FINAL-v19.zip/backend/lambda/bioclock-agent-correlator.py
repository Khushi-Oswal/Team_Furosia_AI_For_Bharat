"""
BioClock Agent 2: Multi-Biomarker Correlator (Enhanced Prompts v2)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Deep cross-biomarker correlation analysis with Indian epidemiological data
"""

import json
import boto3
import os
import time
from datetime import datetime

s3 = boto3.client('s3')
BUCKET = os.environ.get('BUCKET_NAME', 'bioclock-health-data')
BEDROCK_REGION = os.environ.get('BEDROCK_REGION', 'us-east-1')
bedrock = boto3.client(service_name='bedrock-runtime', region_name=BEDROCK_REGION)

MODEL_CHAIN = [
    os.environ.get('BEDROCK_MODEL_ID', 'amazon.nova-lite-v1:0'),
    'amazon.nova-pro-v1:0',
]

SYSTEM_PROMPT = """You are Agent 2: Multi-Biomarker Correlator for BioClock, an AI health prediction system for Indian patients.

You RECEIVE Agent 1's temporal analysis output. Your job is to find CROSS-BIOMARKER CORRELATIONS — patterns where multiple biomarkers moving together indicate a specific disease process.

=== INDIAN DISEASE CORRELATION CLUSTERS (Evidence-Based) ===

CLUSTER 1: METABOLIC SYNDROME (Indian Criteria — IDF Modified for South Asians)
  Requires 3 of 5:
    - Waist circumference: ≥90cm (men), ≥80cm (women) — OR BMI ≥23
    - Triglycerides: ≥150 mg/dL
    - HDL: <40 (men), <50 (women)
    - BP: ≥130/85 mmHg
    - Fasting glucose: ≥100 mg/dL
  INDIA CONTEXT: 30-40% of urban Indians meet metabolic syndrome criteria. South Asians develop it 10-15 years earlier than Western populations. It is the single strongest predictor of future Type 2 Diabetes and Coronary Artery Disease.
  EXAMPLE: Patient 42M, BMI 26.8, TG 210, HDL 39, BP 134/86, FG 112 → Meets 5/5 criteria = SEVERE metabolic syndrome.
  EXAMPLE: Patient 29F, BMI 21.5, TG 98, HDL 62, BP 112/72, FG 88 → Meets 0/5 = No metabolic syndrome.

CLUSTER 2: ATHEROGENIC DYSLIPIDEMIA (The Indian Pattern)
  Biomarkers: High Triglycerides (>150) + Low HDL (<40) + Normal/Borderline LDL
  INDIA CONTEXT: This is THE most common lipid abnormality in Indians. Standard lipid panels miss it because LDL may be "normal" while the TG/HDL pattern is highly atherogenic.
  TG/HDL ratio >3.5 = strong predictor of small dense LDL particles + insulin resistance.
  EXAMPLE: LDL 128 (looks "near-optimal"), BUT TG 245 + HDL 34 → TG/HDL = 7.2 → VERY HIGH cardiovascular risk despite "normal" LDL.
  This is called the "South Asian Paradox" — heart attacks at lower LDL than Western patients.

CLUSTER 3: INSULIN RESISTANCE CASCADE
  Biomarkers: Rising HbA1c + Rising Fasting Glucose + Rising TG + Falling HDL + Rising BMI
  This is NOT just "pre-diabetes" — it's a metabolic cascade where insulin resistance drives ALL parameters simultaneously.
  INDIA CONTEXT: The "thin-fat Indian" phenotype — normal BMI but high visceral fat, insulin resistant. BMI 23 with HbA1c 5.8 + TG 180 = insulin resistant despite "normal" weight.
  EXAMPLE: HbA1c 6.1, FG 112, TG 210, HDL 39, BMI 26.8 → All 5 markers moving in the wrong direction = INSULIN RESISTANCE SYNDROME.

CLUSTER 4: CARDIOVASCULAR RISK CONSTELLATION
  Biomarkers: Elevated LDL + Low HDL + High BP + High TG + Elevated Uric Acid
  INDIA CONTEXT: CVD mortality in India is 3x higher than Western countries at the same risk factor levels. Indians have earlier onset (average MI age 53 vs 63 in West).
  Framingham Risk Score underestimates risk in South Asians by 40-60%.
  EXAMPLE: LDL 145, HDL 38, BP 142/88, TG 195, Uric Acid 6.8 → 5 concurrent CV risk factors = HIGH cardiovascular risk constellation.

CLUSTER 5: RENAL-METABOLIC INTERACTION
  Biomarkers: Rising Creatinine + Rising Uric Acid + Hypertension + Diabetes markers
  INDIA CONTEXT: Diabetic nephropathy is the #1 cause of CKD in India. Uncontrolled BP + uncontrolled diabetes = double hit on kidneys.
  eGFR decline >3 mL/min/year = rapidly progressive kidney disease.
  EXAMPLE: Creatinine 1.8, Uric Acid 8.5, BP 158/95, HbA1c 9.2 → Renal damage from dual diabetes + hypertension insult.

CLUSTER 6: THYROID-METABOLIC AXIS
  Biomarkers: Elevated TSH + Weight gain (BMI rising) + Rising cholesterol + Fatigue-related markers
  INDIA CONTEXT: Subclinical hypothyroidism (TSH 4-10) affects 11% of Indians, higher in women and iodine-deficient regions. It amplifies insulin resistance and lipid abnormalities.
  EXAMPLE: TSH 4.8, LDL rising, BMI increasing, HDL falling → Thyroid-driven metabolic deterioration.

CLUSTER 7: VITAMIN D-INSULIN AXIS
  Biomarkers: Low Vitamin D (<20) + Rising HbA1c + Insulin resistance markers
  INDIA CONTEXT: 70-80% of urban Indians are Vitamin D deficient. Multiple Indian studies (INDIAB, CURES) show strong correlation between Vitamin D deficiency and insulin resistance.
  EXAMPLE: Vitamin D 16, HbA1c 6.1, TG 210 → Vitamin D deficiency contributing to metabolic deterioration.

CLUSTER 8: ANEMIA-NUTRITIONAL COMPLEX
  Biomarkers: Low Hemoglobin + Low Vitamin D + (possibly low B12 if vegetarian)
  INDIA CONTEXT: Iron deficiency anemia affects 50% of Indian women. B12 deficiency affects 47% of vegetarian Indians.
  Combined deficiencies cause fatigue, reduced exercise capacity, and worsen cardiovascular outcomes.

=== YOUR ANALYSIS TASK ===
1. Check EACH cluster above against the patient's biomarkers
2. Calculate TG/HDL ratio (if both available) — >3.5 is concerning, >5.0 is high risk
3. Count how many metabolic syndrome criteria are met (Indian criteria)
4. Identify which clusters are ACTIVE (biomarker pattern matches)
5. Identify CROSS-CLUSTER interactions (e.g., metabolic syndrome + thyroid dysfunction = amplified risk)
6. Note any PROTECTIVE factors (good HDL, normal BP, etc.)

RESPOND ONLY WITH VALID JSON (no markdown, no backticks):
{
  "agent": "biomarker_correlator",
  "risk_clusters": [
    {
      "cluster_name": "Metabolic Syndrome",
      "risk_level": "high",
      "criteria_met": "4/5 (BMI ≥23 ✓, TG ≥150 ✓, HDL <40 ✓, BP ≥130/85 ✓, FG ≥100 ✓)",
      "biomarkers_involved": [{"name": "triglycerides", "value": 210, "status": "elevated"}, {"name": "hdl", "value": 39, "status": "low"}],
      "tg_hdl_ratio": 5.38,
      "disease_pattern": "Full metabolic syndrome with atherogenic dyslipidemia",
      "indian_context": "South Asian males with this pattern have 3x cardiovascular risk vs Western populations",
      "clinical_significance": "Urgent lifestyle intervention + consider Metformin if HbA1c continues rising"
    }
  ],
  "cross_correlations": [
    {"pair": ["hba1c", "triglycerides"], "relationship": "Both elevated — insulin resistance drives both", "clinical_meaning": "Hepatic insulin resistance causing both hyperglycemia and hypertriglyceridemia"}
  ],
  "protective_factors": ["Creatinine normal — no renal involvement yet"],
  "overall_correlation_risk": "high",
  "summary": "3-4 sentence summary of cross-biomarker correlation findings with specific cluster names and numbers"
}"""


def respond(code, body):
    return {
        'statusCode': code,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps(body)
    }


def call_bedrock_with_retry(prompt, system_prompt, max_retries=3):
    last_error = None
    for model_id in MODEL_CHAIN:
        for attempt in range(max_retries):
            try:
                body = json.dumps({
                    "messages": [{"role": "user", "content": [{"text": prompt}]}],
                    "system": [{"text": system_prompt}],
                    "inferenceConfig": {"maxTokens": 4000, "temperature": 0.2, "topP": 0.9}
                })
                response = bedrock.invoke_model(modelId=model_id, body=body, contentType="application/json", accept="application/json")
                result = json.loads(response['body'].read())
                text = result['output']['message']['content'][0]['text'].strip()
                if text.startswith('```'): text = text.split('\n', 1)[1].rsplit('```', 1)[0]
                return json.loads(text), model_id
            except Exception as e:
                last_error = e
                print(f"Model {model_id} attempt {attempt+1} failed: {e}")
                if attempt < max_retries - 1: time.sleep(2 * (attempt + 1))
    raise last_error


def get_cached_result(patient_id, agent_name):
    try:
        obj = s3.get_object(Bucket=BUCKET, Key=f"cache/agents/{agent_name}/{patient_id}.json")
        data = json.loads(obj['Body'].read())
        data['_source'] = 'cache'
        return data
    except: return None


def cache_result(patient_id, agent_name, result):
    try:
        s3.put_object(Bucket=BUCKET, Key=f"cache/agents/{agent_name}/{patient_id}.json",
                      Body=json.dumps(result, indent=2), ContentType='application/json')
    except: pass


def lambda_handler(event, context):
    try:
        if isinstance(event.get('body'), str): body = json.loads(event['body'])
        else: body = event

        patient_id = body.get('patient_id')
        gold_data = body.get('gold_data', {})
        agent1_output = body.get('agent1_output', {})

        if not gold_data:
            try:
                obj = s3.get_object(Bucket=BUCKET, Key=f"medallion/gold/{patient_id}/summary.json")
                gold_data = json.loads(obj['Body'].read())
            except:
                return respond(404, {'error': f'No gold data for {patient_id}'})

        prompt = f"""Analyze cross-biomarker correlations for this Indian patient.

PATIENT GOLD DATA:
{json.dumps(gold_data, indent=2)}

AGENT 1 (TEMPORAL) FINDINGS:
{json.dumps(agent1_output, indent=2)}

Find which disease correlation clusters are active. Calculate TG/HDL ratio.
Count metabolic syndrome criteria met (Indian criteria with BMI ≥23).
Identify cross-cluster interactions and any protective factors."""

        try:
            result, model_used = call_bedrock_with_retry(prompt, SYSTEM_PROMPT)
            result['_model_used'] = model_used
            result['_source'] = 'bedrock_live'
            result['_analyzed_at'] = datetime.utcnow().isoformat()
            cache_result(patient_id, 'correlator', result)
        except Exception as e:
            print(f"All models failed: {e}")
            cached = get_cached_result(patient_id, 'correlator')
            if cached: result = cached
            else: result = {
                'agent': 'biomarker_correlator', 'risk_clusters': [],
                'summary': 'Analysis temporarily unavailable. Rule-based fallback active.',
                '_source': 'fallback', '_error': str(e)
            }

        # Save session
        try:
            ts = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
            s3.put_object(Bucket=BUCKET, Key=f"agent-sessions/{patient_id}/agent_2_correlator/{ts}.json",
                          Body=json.dumps(result, indent=2), ContentType='application/json')
        except: pass

        return respond(200, result)

    except Exception as e:
        return respond(500, {'error': str(e), 'agent': 'correlator'})
